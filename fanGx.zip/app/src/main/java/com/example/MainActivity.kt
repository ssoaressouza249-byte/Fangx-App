package com.example

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.ui.theme.FangxTheme
import com.raylan.fangx.FangxViewModel
import com.raylan.fangx.SecurityGuard
import com.raylan.fangx.SecurityStatus
import com.raylan.fangx.ui.FangxRootScreen
import com.raylan.fangx.ui.TamperLockScreen
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

  private val fangxViewModel: FangxViewModel by viewModels()
  private var onCreateSecurityStatus by mutableStateOf(SecurityStatus(isIntact = true))

  private val binderListener = Shizuku.OnBinderReceivedListener {
    runCatching { fangxViewModel.refreshSystemStatuses() }
  }

  private val binderDeadListener = Shizuku.OnBinderDeadListener {
    runCatching { fangxViewModel.refreshSystemStatuses() }
  }

  private val permissionResultListener =
    Shizuku.OnRequestPermissionResultListener { _, grantResult ->
      runCatching {
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
          fangxViewModel.refreshSystemStatuses()
        } else {
          fangxViewModel.refreshSystemStatuses()
        }
      }
    }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    onCreateSecurityStatus = SecurityGuard.verifyIntegrity(this)

    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
    )

    runCatching {
      Shizuku.addBinderReceivedListenerSticky(binderListener)
      Shizuku.addBinderDeadListener(binderDeadListener)
      Shizuku.addRequestPermissionResultListener(permissionResultListener)
    }

    setContent {
      FangxTheme {
        if (!onCreateSecurityStatus.isIntact) {
          TamperLockScreen(violationReason = onCreateSecurityStatus.violationReason)
        } else {
          FangxRootScreen(viewModel = fangxViewModel)
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    onCreateSecurityStatus = SecurityGuard.verifyIntegrity(this)
    runCatching { fangxViewModel.refreshSystemStatuses() }
  }

  override fun onDestroy() {
    runCatching {
      Shizuku.removeBinderReceivedListener(binderListener)
      Shizuku.removeBinderDeadListener(binderDeadListener)
      Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    }
    super.onDestroy()
  }
}
