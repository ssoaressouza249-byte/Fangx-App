package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FangxDeepBlack = Color(0xFF090A0F)
val FangxGraphite = Color(0xFF131620)
val FangxGraphiteElevated = Color(0xFF1A1E2D)
val FangxCyan = Color(0xFF00F0FF)
val FangxCyanDim = Color(0xFF008F99)
val FangxNeonRed = Color(0xFFFF1E42)
val FangxNeonRedDark = Color(0xFF3A040E)
val FangxTamperBg = Color(0xFF2B0007)
val FangxNeonGreen = Color(0xFF00E676)
val FangxAmber = Color(0xFFFFB300)
val FangxTextPrimary = Color(0xFFF2F6FF)
val FangxTextSecondary = Color(0xFF94A3B8)
val FangxBorderSubtle = Color(0xFF232A3E)
