package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val FangxDarkColorScheme =
  darkColorScheme(
    primary = FangxCyan,
    onPrimary = FangxDeepBlack,
    primaryContainer = FangxGraphiteElevated,
    onPrimaryContainer = FangxCyan,
    secondary = FangxNeonRed,
    onSecondary = FangxTextPrimary,
    secondaryContainer = FangxNeonRedDark,
    onSecondaryContainer = FangxTextPrimary,
    tertiary = FangxNeonGreen,
    onTertiary = FangxDeepBlack,
    background = FangxDeepBlack,
    onBackground = FangxTextPrimary,
    surface = FangxGraphite,
    onSurface = FangxTextPrimary,
    surfaceVariant = FangxGraphiteElevated,
    onSurfaceVariant = FangxTextSecondary,
    outline = FangxCyan,
    outlineVariant = FangxBorderSubtle,
    error = FangxNeonRed,
    onError = FangxTextPrimary,
    errorContainer = FangxNeonRedDark,
    onErrorContainer = FangxTextPrimary,
  )

private val FangxShapes =
  Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp),
  )

@Composable
fun FangxTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = FangxDarkColorScheme,
    typography = Typography,
    shapes = FangxShapes,
    content = content,
  )
}
