package com.raylan.fangx.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FangxNeonRed
import com.example.ui.theme.FangxNeonRedDark
import com.example.ui.theme.FangxTamperBg
import com.example.ui.theme.FangxTextPrimary
import com.raylan.fangx.SecurityGuard

@Composable
fun TamperLockScreen(
  violationReason: String?,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current

  // Bloqueio irremovível do botão Voltar do sistema
  BackHandler(enabled = true) {}

  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(FangxTamperBg, FangxNeonRedDark, FangxTamperBg)
          )
        )
        .systemBarsPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .border(2.dp, FangxNeonRed, RoundedCornerShape(16.dp))
          .background(FangxTamperBg.copy(alpha = 0.92f), RoundedCornerShape(16.dp))
          .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = Icons.Filled.Warning,
        contentDescription = "Alerta de modificação não autorizada",
        tint = FangxNeonRed,
        modifier = Modifier.size(72.dp),
      )

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "PROTEÇÃO ANTI-MODIFICAÇÃO",
        style = MaterialTheme.typography.labelLarge,
        color = FangxNeonRed,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp,
      )

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = SecurityGuard.TAMPER_MESSAGE,
        color = FangxTextPrimary,
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 17.sp,
        lineHeight = 24.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.testTag("tamper_lock_message"),
      )

      if (!violationReason.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "Detecção: $violationReason",
          color = FangxNeonRed.copy(alpha = 0.85f),
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          textAlign = TextAlign.Center,
        )
      }

      Spacer(modifier = Modifier.height(28.dp))

      Button(
        onClick = { SecurityGuard.launchSelfUninstall(context) },
        colors =
          ButtonDefaults.buttonColors(
            containerColor = FangxNeonRed,
            contentColor = FangxTextPrimary,
          ),
        shape = RoundedCornerShape(12.dp),
        modifier =
          Modifier
            .fillMaxWidth()
            .height(64.dp)
            .testTag("uninstall_tampered_app_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.DeleteForever,
          contentDescription = null,
          modifier = Modifier.size(26.dp),
        )
        Spacer(modifier = Modifier.size(10.dp))
        Text(
          text = "DESINSTALAR APP AGORA",
          fontFamily = FontFamily.Default,
          fontWeight = FontWeight.Black,
          fontSize = 16.sp,
          letterSpacing = 1.sp,
        )
      }
    }
  }
}
