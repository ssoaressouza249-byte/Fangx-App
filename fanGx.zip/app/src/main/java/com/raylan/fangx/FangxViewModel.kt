package com.raylan.fangx

import android.app.Application
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.fangx.overlay.CrosshairColorOption
import com.raylan.fangx.overlay.CrosshairConfig
import com.raylan.fangx.overlay.CrosshairStyle
import com.raylan.fangx.overlay.FangxOverlayService
import com.raylan.fangx.overlay.OverlayStateStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class GameTarget(val label: String, val packageName: String) {
  FREE_FIRE_NORMAL("FREE FIRE NORMAL", DeviceTelemetryDetector.PKG_FREE_FIRE_NORMAL),
  FREE_FIRE_MAX("FREE FIRE MAX", DeviceTelemetryDetector.PKG_FREE_FIRE_MAX),
}

enum class TerminalMode {
  INJECT,
  RESTORE,
}

data class TerminalLogEntry(
  val index: Int,
  val command: String,
  val statusTag: String,
  val isError: Boolean = false,
)

data class TerminalSessionState(
  val isVisible: Boolean = false,
  val mode: TerminalMode = TerminalMode.INJECT,
  val isRunning: Boolean = false,
  val isCompleted: Boolean = false,
  val currentStep: Int = 0,
  val totalSteps: Int = 0,
  val currentCommand: String = "",
  val usedShizuku: Boolean = false,
  val copiedForBrevent: Boolean = false,
  val gameAutoLaunched: Boolean = false,
  val logs: List<TerminalLogEntry> = emptyList(),
)

data class FangxUiState(
  val securityStatus: SecurityStatus = SecurityStatus(isIntact = true),
  val deviceInfo: DeviceInfo,
  val selectedRefreshRateHz: Int = 90,
  val enabledModules: Set<EngineModule> =
    setOf(EngineModule.AIMBOT, EngineModule.AIMLOCK, EngineModule.LIGHT_UI),
  val moduleCompatibilityMap: Map<EngineModule, ModuleCompatibility> = emptyMap(),
  val compatibleAimCount: Int = 0,
  val compatiblePerformanceCount: Int = 0,
  val selectedGame: GameTarget = GameTarget.FREE_FIRE_NORMAL,
  val shizukuState: ShizukuConnectionState = ShizukuConnectionState.NOT_RUNNING,
  val sensitivityProfile: SensitivityProfile,
  val terminal: TerminalSessionState = TerminalSessionState(),
  val hasOverlayPermission: Boolean = false,
  val snackbarMessage: String? = null,
)

class FangxViewModel(application: Application) : AndroidViewModel(application) {

  private val initialDeviceInfo = DeviceTelemetryDetector.detect(application)
  private val initialHz =
    when {
      initialDeviceInfo.maxRefreshRateHz >= 144 -> 144
      initialDeviceInfo.maxRefreshRateHz >= 120 -> 120
      initialDeviceInfo.maxRefreshRateHz >= 90 -> 90
      else -> 90
    }

  private val _uiState =
    MutableStateFlow(
      FangxUiState(
        securityStatus = SecurityGuard.verifyIntegrity(application),
        deviceInfo = initialDeviceInfo,
        selectedRefreshRateHz = initialHz,
        sensitivityProfile = SensitivityGenerator.generate(initialDeviceInfo),
        hasOverlayPermission = runCatching { Settings.canDrawOverlays(application) }.getOrDefault(false),
      )
    )
  val uiState: StateFlow<FangxUiState> = _uiState.asStateFlow()

  val crosshairConfig: StateFlow<CrosshairConfig> = OverlayStateStore.config

  init {
    recalculateCompatibility()
    refreshSystemStatuses()
    startContinuousSecurityMonitor()
  }

  private fun startContinuousSecurityMonitor() {
    viewModelScope.launch {
      while (isActive) {
        runCatching {
          val status = SecurityGuard.verifyIntegrity(getApplication())
          if (status != _uiState.value.securityStatus) {
            _uiState.update { it.copy(securityStatus = status) }
          }
        }
        delay(1500L)
      }
    }
  }

  fun refreshSystemStatuses() {
    viewModelScope.launch {
      runCatching {
        val ctx = getApplication<Application>()
        val device = DeviceTelemetryDetector.detect(ctx)
        val shizuku = ShizukuBreventBridge.getShizukuState(ctx)
        val overlayAllowed = runCatching { Settings.canDrawOverlays(ctx) }.getOrDefault(false)
        val security = SecurityGuard.verifyIntegrity(ctx)
        _uiState.update { state ->
          state.copy(
            securityStatus = security,
            deviceInfo = device,
            shizukuState = shizuku,
            hasOverlayPermission = overlayAllowed,
          )
        }
        recalculateCompatibility()
      }
    }
  }

  private fun recalculateCompatibility() {
    val state = _uiState.value
    val device = state.deviceInfo
    val hz = state.selectedRefreshRateHz
    val compatMap =
      EngineModule.entries.associateWith { module ->
        MassiveCommandEngine.evaluateModuleCompatibility(module, device, hz)
      }
    val validEnabled =
      state.enabledModules.filter { compatMap[it]?.isCompatible == true }.toSet()
    val aimCount =
      MassiveCommandEngine.countCompatibleInBank(CommandBank.AIM, device, hz)
    val perfCount =
      MassiveCommandEngine.countCompatibleInBank(CommandBank.PERFORMANCE, device, hz)

    _uiState.update {
      it.copy(
        moduleCompatibilityMap = compatMap,
        enabledModules = validEnabled,
        compatibleAimCount = aimCount,
        compatiblePerformanceCount = perfCount,
      )
    }
  }

  fun toggleModule(module: EngineModule) {
    val compat = _uiState.value.moduleCompatibilityMap[module] ?: return
    if (!compat.isCompatible) return
    _uiState.update { state ->
      val next =
        if (module in state.enabledModules) state.enabledModules - module
        else state.enabledModules + module
      state.copy(enabledModules = next)
    }
  }

  fun selectRefreshRate(hz: Int) {
    if (_uiState.value.deviceInfo.maxRefreshRateHz < hz) return
    _uiState.update { it.copy(selectedRefreshRateHz = hz) }
    recalculateCompatibility()
  }

  fun selectGame(target: GameTarget) {
    _uiState.update { it.copy(selectedGame = target) }
  }

  fun generateNewSensitivity() {
    runCatching {
      val profile = SensitivityGenerator.generate(_uiState.value.deviceInfo)
      _uiState.update { it.copy(sensitivityProfile = profile) }
    }
  }

  fun copySensitivityAndTips() {
    val ctx = getApplication<Application>()
    val ok =
      ShizukuBreventBridge.copyTextToClipboard(
        ctx,
        "Fangx Sensi",
        _uiState.value.sensitivityProfile.toClipboardText(),
      )
    _uiState.update {
      it.copy(
        snackbarMessage =
          if (ok) "Sensi, DPI e dicas copiados para a área de transferência!"
          else "Não foi possível copiar para a área de transferência."
      )
    }
  }

  fun clearSnackbar() {
    _uiState.update { it.copy(snackbarMessage = null) }
  }

  fun requestShizukuPermission() {
    val requested = ShizukuBreventBridge.requestShizukuPermission()
    if (!requested) {
      val opened =
        ShizukuBreventBridge.launchApp(getApplication(), DeviceTelemetryDetector.PKG_SHIZUKU)
      _uiState.update {
        it.copy(
          snackbarMessage =
            if (opened) "Abrindo Shizuku para ativar o serviço..."
            else "Shizuku não detectado. Use o modo Brevent automático!"
        )
      }
    }
  }

  fun startCadencedInjection() {
    val state = _uiState.value
    val queue =
      MassiveCommandEngine.buildSelectedCommandQueue(
        enabledModules = state.enabledModules,
        deviceInfo = state.deviceInfo,
        selectedHz = state.selectedRefreshRateHz,
      )
    if (queue.isEmpty()) {
      _uiState.update {
        it.copy(snackbarMessage = "Ative pelo menos um módulo compatível antes de injetar.")
      }
      return
    }
    runCadencedQueue(queue = queue, mode = TerminalMode.INJECT)
  }

  fun startRestoreFactoryDefaults() {
    val state = _uiState.value
    val queue =
      MassiveCommandEngine.buildRestoreFactoryQueue(
        deviceInfo = state.deviceInfo,
        selectedHz = state.selectedRefreshRateHz,
      )
    if (queue.isEmpty()) return
    runCadencedQueue(queue = queue, mode = TerminalMode.RESTORE)
  }

  private fun runCadencedQueue(queue: List<String>, mode: TerminalMode) {
    val ctx = getApplication<Application>()
    val shizukuState = ShizukuBreventBridge.getShizukuState(ctx)
    val useShizuku = shizukuState == ShizukuConnectionState.CONNECTED

    _uiState.update {
      it.copy(
        shizukuState = shizukuState,
        terminal =
          TerminalSessionState(
            isVisible = true,
            mode = mode,
            isRunning = true,
            isCompleted = false,
            currentStep = 0,
            totalSteps = queue.size,
            currentCommand = "Inicializando motor cadenciado (40ms anti-conflito)...",
            usedShizuku = useShizuku,
            copiedForBrevent = false,
            gameAutoLaunched = false,
            logs = emptyList(),
          ),
      )
    }

    viewModelScope.launch {
      runCatching {
        val logBuffer = mutableListOf<TerminalLogEntry>()
        queue.forEachIndexed { idx, cmd ->
          val step = idx + 1
          val resultTag: String
          val isErr: Boolean

          if (useShizuku) {
            val exec = ShizukuBreventBridge.executeCommandViaShizuku(cmd)
            resultTag = if (exec.success) "OK" else "AVISO"
            isErr = !exec.success
          } else {
            resultTag = "PREPARADO"
            isErr = false
          }

          logBuffer.add(
            TerminalLogEntry(
              index = step,
              command = cmd,
              statusTag = resultTag,
              isError = isErr,
            )
          )

          _uiState.update { s ->
            s.copy(
              terminal =
                s.terminal.copy(
                  currentStep = step,
                  currentCommand = "[$step/${queue.size}] Aplicando comando...",
                  logs = logBuffer.takeLast(60),
                )
            )
          }

          // Intervalo cadenciado obrigatório de 40ms para evitar conflito no sistema Android
          delay(40L)
        }

        var copiedBrevent = false
        var launchedGame = false

        if (useShizuku && mode == TerminalMode.INJECT) {
          launchedGame =
            ShizukuBreventBridge.launchApp(ctx, _uiState.value.selectedGame.packageName)
        } else {
          copiedBrevent =
            ShizukuBreventBridge.copyCommandsToClipboard(
              ctx,
              "Fangx Comandos",
              queue,
            )
        }

        _uiState.update { s ->
          s.copy(
            terminal =
              s.terminal.copy(
                isRunning = false,
                isCompleted = true,
                currentStep = queue.size,
                currentCommand =
                  if (mode == TerminalMode.RESTORE) {
                    "Restauração concluída (${queue.size}/${queue.size})."
                  } else if (useShizuku) {
                    "100% Injetado via Shizuku! ${if (launchedGame) "Abrindo Free Fire..." else "Pronto para jogar!"}"
                  } else {
                    "100% Fila pronta! Comandos copiados para Brevent."
                  },
                copiedForBrevent = copiedBrevent,
                gameAutoLaunched = launchedGame,
              )
          )
        }
      }
        .onFailure { err ->
          _uiState.update { s ->
            s.copy(
              terminal =
                s.terminal.copy(
                  isRunning = false,
                  isCompleted = true,
                  currentCommand = "Concluído com aviso: ${err.message}",
                )
            )
          }
        }
    }
  }

  fun closeTerminalIfFinished() {
    if (_uiState.value.terminal.isCompleted && !_uiState.value.terminal.isRunning) {
      _uiState.update { it.copy(terminal = TerminalSessionState()) }
    }
  }

  fun openBrevent() {
    val opened =
      ShizukuBreventBridge.launchApp(getApplication(), DeviceTelemetryDetector.PKG_BREVENT)
    if (!opened) {
      _uiState.update {
        it.copy(snackbarMessage = "Brevent (me.piebridge.brevent) não está instalado.")
      }
    }
  }

  fun openSelectedFreeFire() {
    val target = _uiState.value.selectedGame
    val opened = ShizukuBreventBridge.launchApp(getApplication(), target.packageName)
    if (!opened) {
      _uiState.update {
        it.copy(snackbarMessage = "${target.label} (${target.packageName}) não está instalado.")
      }
    }
  }

  fun toggleFloatingOverlay(onNeedPermission: () -> Unit) {
    val ctx = getApplication<Application>()
    val canDraw = runCatching { Settings.canDrawOverlays(ctx) }.getOrDefault(false)
    _uiState.update { it.copy(hasOverlayPermission = canDraw) }

    if (!canDraw) {
      onNeedPermission()
      return
    }

    if (crosshairConfig.value.isOverlayActive) {
      FangxOverlayService.stop(ctx)
    } else {
      FangxOverlayService.start(ctx)
    }
  }

  fun updateCrosshairStyle(style: CrosshairStyle) {
    OverlayStateStore.update { it.copy(style = style) }
  }

  fun updateCrosshairColor(color: CrosshairColorOption) {
    OverlayStateStore.update { it.copy(colorOption = color) }
  }

  fun updateCrosshairSize(sizeDp: Float) {
    OverlayStateStore.update { it.copy(sizeDp = sizeDp.coerceIn(12f, 48f)) }
  }

  fun toggleCrosshairVisibility() {
    OverlayStateStore.update { it.copy(showCrosshair = !it.showCrosshair) }
  }
}
