package com.raylan.fangx

enum class CommandBank {
  AIM,
  PERFORMANCE,
}

enum class EngineModule(
  val title: String,
  val bank: CommandBank,
  val description: String,
  val minModuleSdk: Int = 26,
  val minModuleHz: Int = 0,
) {
  AIMBOT(
    title = "Aimbot",
    bank = CommandBank.AIM,
    description = "Calibração agressiva de ponteiro e resposta inicial de toque",
  ),
  AIMLOCK(
    title = "Aimlock",
    bank = CommandBank.AIM,
    description = "Estabilização de micro-movimentos e precisão de eixo vertical",
  ),
  NO_RECOIL(
    title = "No Recoil",
    bank = CommandBank.AIM,
    description = "Redução de atraso de toque contínuo e suavização de arrasto",
  ),
  AIMBOT_2X(
    title = "Aimbot 2x",
    bank = CommandBank.AIM,
    description = "Ajuste fino de sensibilidade para miras 2x e médio alcance",
  ),
  HS_75(
    title = "HS 75%",
    bank = CommandBank.AIM,
    description = "Otimização de subida de capa e resposta ultrarrápida de toque",
  ),
  BONECO_LENTO(
    title = "Boneco Lento (Fast Move)",
    bank = CommandBank.AIM,
    description = "Latência mínima de gestos, movimentação e transição de mira",
  ),
  BOOST_CPU_GPU(
    title = "Boost CPU & GPU + Cravar 90~100 FPS",
    bank = CommandBank.PERFORMANCE,
    description = "Game Manager API, modo performance e taxa de atualização elevada",
    minModuleSdk = 31,
    minModuleHz = 90,
  ),
  LIGHT_UI(
    title = "Interface Leve & Otimizar Todos os Apps",
    bank = CommandBank.PERFORMANCE,
    description = "Animações em 0.0x, redução de blur, cache trim e compilação ART",
  ),
  NO_FRAME_DROP(
    title = "Jogar Sem Queda de Taxa de Quadros",
    bank = CommandBank.PERFORMANCE,
    description = "Liberação de RAM em segundo plano, Doze whitelist e térmica",
  ),
  EXTREME_ACCEL(
    title = "Aceleração Extrema do Sistema Android",
    bank = CommandBank.PERFORMANCE,
    description = "Desativa logs, tracing e verificações pesadas do sistema",
  ),
}

data class CommandSpec(
  val id: Int,
  val module: EngineModule,
  val commandBuilder: (DeviceInfo, Int) -> String,
  val restoreCommand: String,
  val minSdk: Int = 26,
  val minRefreshRateHz: Int = 0,
  val supportedBrands: Set<DeviceBrand> = emptySet(),
) {
  fun isCompatible(deviceInfo: DeviceInfo, selectedHz: Int): Boolean {
    if (deviceInfo.sdkInt < minSdk) return false
    if (minRefreshRateHz > 0 && deviceInfo.maxRefreshRateHz < minRefreshRateHz) return false
    if (minRefreshRateHz > 0 && selectedHz < minRefreshRateHz) return false
    if (supportedBrands.isNotEmpty() && deviceInfo.brandCategory !in supportedBrands) return false
    return true
  }
}

data class ModuleCompatibility(
  val module: EngineModule,
  val isCompatible: Boolean,
  val incompatibleReason: String?,
  val compatibleCommands: List<CommandSpec>,
  val totalCommands: Int,
)

object MassiveCommandEngine {

  val EXPECTED_MODULE_TITLES: List<String> =
    listOf(
      "Aimbot",
      "Aimlock",
      "No Recoil",
      "Aimbot 2x",
      "HS 75%",
      "Boneco Lento (Fast Move)",
      "Boost CPU & GPU + Cravar 90~100 FPS",
      "Interface Leve & Otimizar Todos os Apps",
      "Jogar Sem Queda de Taxa de Quadros",
      "Aceleração Extrema do Sistema Android",
    )

  fun verifyInternalModuleIntegrity(): Boolean =
    runCatching {
        val currentTitles = EngineModule.entries.map { it.title }
        currentTitles == EXPECTED_MODULE_TITLES &&
          allCommands.size == 200 &&
          aimCommands.size == 100 &&
          performanceCommands.size == 100
      }
      .getOrDefault(false)

  val allCommands: List<CommandSpec> by lazy { buildAll200Commands() }

  val aimCommands: List<CommandSpec> by lazy {
    allCommands.filter { it.module.bank == CommandBank.AIM }
  }

  val performanceCommands: List<CommandSpec> by lazy {
    allCommands.filter { it.module.bank == CommandBank.PERFORMANCE }
  }

  fun evaluateModuleCompatibility(
    module: EngineModule,
    deviceInfo: DeviceInfo,
    selectedHz: Int,
  ): ModuleCompatibility {
    val moduleSpecs = allCommands.filter { it.module == module }
    if (deviceInfo.sdkInt < module.minModuleSdk) {
      return ModuleCompatibility(
        module = module,
        isCompatible = false,
        incompatibleReason = "Requer Android 12+ (SDK ${module.minModuleSdk}+) para cmd game",
        compatibleCommands = emptyList(),
        totalCommands = moduleSpecs.size,
      )
    }
    if (module.minModuleHz > 0 && deviceInfo.maxRefreshRateHz < module.minModuleHz) {
      return ModuleCompatibility(
        module = module,
        isCompatible = false,
        incompatibleReason =
          "Requer display >= ${module.minModuleHz}Hz (detectado: ${deviceInfo.maxRefreshRateHz}Hz)",
        compatibleCommands = emptyList(),
        totalCommands = moduleSpecs.size,
      )
    }
    val compatible = moduleSpecs.filter { it.isCompatible(deviceInfo, selectedHz) }
    if (compatible.isEmpty()) {
      return ModuleCompatibility(
        module = module,
        isCompatible = false,
        incompatibleReason = "Nenhum comando compatível com ${deviceInfo.model}",
        compatibleCommands = emptyList(),
        totalCommands = moduleSpecs.size,
      )
    }
    return ModuleCompatibility(
      module = module,
      isCompatible = true,
      incompatibleReason = null,
      compatibleCommands = compatible,
      totalCommands = moduleSpecs.size,
    )
  }

  fun countCompatibleInBank(
    bank: CommandBank,
    deviceInfo: DeviceInfo,
    selectedHz: Int,
  ): Int {
    return EngineModule.entries
      .filter { it.bank == bank }
      .sumOf { module ->
        evaluateModuleCompatibility(module, deviceInfo, selectedHz).compatibleCommands.size
      }
  }

  fun buildSelectedCommandQueue(
    enabledModules: Set<EngineModule>,
    deviceInfo: DeviceInfo,
    selectedHz: Int,
  ): List<String> {
    val queue = mutableListOf<String>()
    EngineModule.entries.forEach { module ->
      if (module in enabledModules) {
        val compat = evaluateModuleCompatibility(module, deviceInfo, selectedHz)
        if (compat.isCompatible) {
          compat.compatibleCommands.forEach { spec ->
            queue.add(spec.commandBuilder(deviceInfo, selectedHz))
          }
        }
      }
    }
    return queue
  }

  fun buildRestoreFactoryQueue(deviceInfo: DeviceInfo, selectedHz: Int): List<String> {
    return allCommands
      .filter { it.isCompatible(deviceInfo, selectedHz) && it.restoreCommand.isNotBlank() }
      .map { it.restoreCommand }
      .distinct()
  }

  private fun buildAll200Commands(): List<CommandSpec> {
    var nextId = 1
    fun add(
      module: EngineModule,
      restore: String,
      minSdk: Int = 26,
      minHz: Int = 0,
      brands: Set<DeviceBrand> = emptySet(),
      builder: (DeviceInfo, Int) -> String,
    ): CommandSpec {
      return CommandSpec(
        id = nextId++,
        module = module,
        commandBuilder = builder,
        restoreCommand = restore,
        minSdk = minSdk,
        minRefreshRateHz = minHz,
        supportedBrands = brands,
      )
    }

    val list = mutableListOf<CommandSpec>()

    // =========================================================================
    // BANCO A: 100 COMANDOS DE MIRA, TOQUE & PRECISÃO
    // =========================================================================

    // 1. AIMBOT (17 comandos)
    list += add(EngineModule.AIMBOT, "settings put system pointer_speed 0") { d, _ ->
      val speed = if (d.dpi >= 480) 7 else 6
      "settings put system pointer_speed $speed"
    }
    list += add(EngineModule.AIMBOT, "settings put secure long_press_timeout 400") { _, _ ->
      "settings put secure long_press_timeout 200"
    }
    list += add(EngineModule.AIMBOT, "settings put secure multi_press_timeout 300") { _, _ ->
      "settings put secure multi_press_timeout 150"
    }
    list += add(EngineModule.AIMBOT, "settings put secure tap_duration_threshold 0.0", minSdk = 29) { _, _ ->
      "settings put secure tap_duration_threshold 0.0"
    }
    list += add(EngineModule.AIMBOT, "settings put secure touch_blocking_period 0.0", minSdk = 29) { _, _ ->
      "settings put secure touch_blocking_period 0.0"
    }
    list += add(EngineModule.AIMBOT, "settings put secure accessibility_large_pointer_icon 0") { _, _ ->
      "settings put secure accessibility_large_pointer_icon 0"
    }
    list += add(EngineModule.AIMBOT, "settings put system show_touches 0") { _, _ ->
      "settings put system show_touches 0"
    }
    list += add(EngineModule.AIMBOT, "settings put system pointer_location 0") { _, _ ->
      "settings put system pointer_location 0"
    }
    list += add(EngineModule.AIMBOT, "settings put secure touch_exploration_enabled 0") { _, _ ->
      "settings put secure touch_exploration_enabled 0"
    }
    list += add(EngineModule.AIMBOT, "settings put system haptic_feedback_enabled 1") { _, _ ->
      "settings put system haptic_feedback_enabled 0"
    }
    list += add(EngineModule.AIMBOT, "settings put system sound_effects_enabled 1") { _, _ ->
      "settings put system sound_effects_enabled 0"
    }
    list += add(EngineModule.AIMBOT, "settings put secure back_gesture_inset_scale_left 1.0", minSdk = 29) { _, _ ->
      "settings put secure back_gesture_inset_scale_left 0.5"
    }
    list += add(EngineModule.AIMBOT, "settings put secure back_gesture_inset_scale_right 1.0", minSdk = 29) { _, _ ->
      "settings put secure back_gesture_inset_scale_right 0.5"
    }
    list += add(
      EngineModule.AIMBOT,
      "settings put system sem_enhanced_cpu_responsiveness 0",
      brands = setOf(DeviceBrand.SAMSUNG),
    ) { _, _ ->
      "settings put system sem_enhanced_cpu_responsiveness 1"
    }
    list += add(
      EngineModule.AIMBOT,
      "settings put system speed_mode 0",
      brands = setOf(DeviceBrand.XIAOMI),
    ) { _, _ ->
      "settings put system speed_mode 1"
    }
    list += add(
      EngineModule.AIMBOT,
      "settings put system touch_mode 0",
      brands = setOf(DeviceBrand.XIAOMI),
    ) { _, _ ->
      "settings put system touch_mode 1"
    }
    list += add(EngineModule.AIMBOT, "settings put global window_animation_scale 1.0") { _, _ ->
      "settings put global window_animation_scale 0.5"
    }

    // 2. AIMLOCK (17 comandos)
    list += add(EngineModule.AIMLOCK, "settings put system pointer_speed 0") { d, _ ->
      val calibrated = if (d.widthPx >= 1200) 7 else 6
      "settings put system pointer_speed $calibrated"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure autoclick_enabled 0") { _, _ ->
      "settings put secure autoclick_enabled 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure autoclick_delay 600") { _, _ ->
      "settings put secure autoclick_delay 200"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure accessibility_bounce_keys 0", minSdk = 29) { _, _ ->
      "settings put secure accessibility_bounce_keys 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure accessibility_slow_keys 0", minSdk = 29) { _, _ ->
      "settings put secure accessibility_slow_keys 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure accessibility_sticky_keys 0", minSdk = 29) { _, _ ->
      "settings put secure accessibility_sticky_keys 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure stylus_handwriting_enabled 1", minSdk = 33) { _, _ ->
      "settings put secure stylus_handwriting_enabled 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put system dtmf_tone 1") { _, _ ->
      "settings put system dtmf_tone 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put system lockscreen_sounds_enabled 1") { _, _ ->
      "settings put system lockscreen_sounds_enabled 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put system vibrate_when_ringing 1") { _, _ ->
      "settings put system vibrate_when_ringing 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure double_tap_to_wake 1") { _, _ ->
      "settings put secure double_tap_to_wake 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure wake_gesture_enabled 1") { _, _ ->
      "settings put secure wake_gesture_enabled 0"
    }
    list += add(EngineModule.AIMLOCK, "settings put secure edge_long_press_timeout 400", minSdk = 30) { _, _ ->
      "settings put secure edge_long_press_timeout 180"
    }
    list += add(
      EngineModule.AIMLOCK,
      "settings put system increase_touch_sensitivity 0",
      brands = setOf(DeviceBrand.SAMSUNG),
    ) { _, _ ->
      "settings put system increase_touch_sensitivity 1"
    }
    list += add(
      EngineModule.AIMLOCK,
      "settings put global moto_touch_boost 0",
      brands = setOf(DeviceBrand.MOTOROLA),
    ) { _, _ ->
      "settings put global moto_touch_boost 1"
    }
    list += add(
      EngineModule.AIMLOCK,
      "settings put system gt_mode_state_key 0",
      brands = setOf(DeviceBrand.REALME),
    ) { _, _ ->
      "settings put system gt_mode_state_key 1"
    }
    list += add(EngineModule.AIMLOCK, "wm tracing stop") { _, _ ->
      "wm tracing stop"
    }

    // 3. NO RECOIL (17 comandos)
    list += add(EngineModule.NO_RECOIL, "settings put secure long_press_timeout 400") { _, _ ->
      "settings put secure long_press_timeout 175"
    }
    list += add(EngineModule.NO_RECOIL, "settings put secure multi_press_timeout 300") { _, _ ->
      "settings put secure multi_press_timeout 135"
    }
    list += add(EngineModule.NO_RECOIL, "settings put secure tap_duration_threshold 0.0", minSdk = 29) { _, _ ->
      "settings put secure tap_duration_threshold 0.01"
    }
    list += add(EngineModule.NO_RECOIL, "settings put secure touch_blocking_period 0.0", minSdk = 29) { _, _ ->
      "settings put secure touch_blocking_period 0.0"
    }
    list += add(EngineModule.NO_RECOIL, "settings put system pointer_speed 0") { d, _ ->
      val spd = if (d.maxRefreshRateHz >= 120) 7 else 5
      "settings put system pointer_speed $spd"
    }
    list += add(EngineModule.NO_RECOIL, "settings put global transition_animation_scale 1.0") { _, _ ->
      "settings put global transition_animation_scale 0.25"
    }
    list += add(EngineModule.NO_RECOIL, "settings put global animator_duration_scale 1.0") { _, _ ->
      "settings put global animator_duration_scale 0.25"
    }
    list += add(EngineModule.NO_RECOIL, "settings put secure adaptive_sleep 1", minSdk = 29) { _, _ ->
      "settings put secure adaptive_sleep 0"
    }
    list += add(EngineModule.NO_RECOIL, "settings put secure doze_enabled 1") { _, _ ->
      "settings put secure doze_enabled 0"
    }
    list += add(EngineModule.NO_RECOIL, "settings put secure doze_always_on 1") { _, _ ->
      "settings put secure doze_always_on 0"
    }
    list += add(EngineModule.NO_RECOIL, "settings put secure screensaver_enabled 1") { _, _ ->
      "settings put secure screensaver_enabled 0"
    }
    list += add(EngineModule.NO_RECOIL, "settings put system haptic_feedback_intensity 2", minSdk = 29) { _, _ ->
      "settings put system haptic_feedback_intensity 0"
    }
    list += add(EngineModule.NO_RECOIL, "settings put system notification_vibration_intensity 2", minSdk = 29) { _, _ ->
      "settings put system notification_vibration_intensity 0"
    }
    list += add(EngineModule.NO_RECOIL, "settings put system ring_vibration_intensity 2", minSdk = 29) { _, _ ->
      "settings put system ring_vibration_intensity 0"
    }
    list += add(
      EngineModule.NO_RECOIL,
      "settings put system asus_touch_sampling 0",
      brands = setOf(DeviceBrand.ASUS),
    ) { _, _ ->
      "settings put system asus_touch_sampling 1"
    }
    list += add(
      EngineModule.NO_RECOIL,
      "settings put system glove_mode 0",
      brands = setOf(DeviceBrand.ASUS),
    ) { _, _ ->
      "settings put system glove_mode 1"
    }
    list += add(EngineModule.NO_RECOIL, "settings put global fancy_ime_animations 1") { _, _ ->
      "settings put global fancy_ime_animations 0"
    }

    // 4. AIMBOT 2X (17 comandos)
    list += add(EngineModule.AIMBOT_2X, "settings put system pointer_speed 0") { d, _ ->
      val speed2x = if (d.dpi >= 440) 6 else 5
      "settings put system pointer_speed $speed2x"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put secure long_press_timeout 400") { _, _ ->
      "settings put secure long_press_timeout 190"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put secure multi_press_timeout 300") { _, _ ->
      "settings put secure multi_press_timeout 140"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put secure back_gesture_inset_scale_left 1.0", minSdk = 29) { _, _ ->
      "settings put secure back_gesture_inset_scale_left 0.4"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put secure back_gesture_inset_scale_right 1.0", minSdk = 29) { _, _ ->
      "settings put secure back_gesture_inset_scale_right 0.4"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put secure accessibility_captioning_enabled 0") { _, _ ->
      "settings put secure accessibility_captioning_enabled 0"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put secure accessibility_display_inversion_enabled 0") { _, _ ->
      "settings put secure accessibility_display_inversion_enabled 0"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put secure accessibility_display_daltonizer_enabled 0") { _, _ ->
      "settings put secure accessibility_display_daltonizer_enabled 0"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put secure high_text_contrast_enabled 0") { _, _ ->
      "settings put secure high_text_contrast_enabled 0"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put system font_scale 1.0") { _, _ ->
      "settings put system font_scale 1.0"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put system accelerometer_rotation 1") { _, _ ->
      "settings put system accelerometer_rotation 0"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put system user_rotation 0") { _, _ ->
      "settings put system user_rotation 1"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put system screen_brightness_mode 1") { _, _ ->
      "settings put system screen_brightness_mode 0"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put global disable_window_blurs 0", minSdk = 31) { _, _ ->
      "settings put global disable_window_blurs 1"
    }
    list += add(EngineModule.AIMBOT_2X, "settings put global accessibility_reduce_transparency 0", minSdk = 31) { _, _ ->
      "settings put global accessibility_reduce_transparency 1"
    }
    list += add(
      EngineModule.AIMBOT_2X,
      "settings put global gb_boosting 0",
      brands = setOf(DeviceBrand.XIAOMI),
    ) { _, _ ->
      "settings put global gb_boosting 1"
    }
    list += add(EngineModule.AIMBOT_2X, "wm set-fix-to-user-rotation disabled", minSdk = 30) { _, _ ->
      "wm set-fix-to-user-rotation disabled"
    }

    // 5. HS 75% (16 comandos)
    list += add(EngineModule.HS_75, "settings put system pointer_speed 0") { _, _ ->
      "settings put system pointer_speed 7"
    }
    list += add(EngineModule.HS_75, "settings put secure long_press_timeout 400") { _, _ ->
      "settings put secure long_press_timeout 160"
    }
    list += add(EngineModule.HS_75, "settings put secure multi_press_timeout 300") { _, _ ->
      "settings put secure multi_press_timeout 120"
    }
    list += add(EngineModule.HS_75, "settings put secure tap_duration_threshold 0.0", minSdk = 29) { _, _ ->
      "settings put secure tap_duration_threshold 0.0"
    }
    list += add(EngineModule.HS_75, "settings put secure touch_blocking_period 0.0", minSdk = 29) { _, _ ->
      "settings put secure touch_blocking_period 0.0"
    }
    list += add(EngineModule.HS_75, "settings put secure edge_long_press_timeout 400", minSdk = 30) { _, _ ->
      "settings put secure edge_long_press_timeout 150"
    }
    list += add(EngineModule.HS_75, "settings put system touch_slop 8") { _, _ ->
      "settings put system touch_slop 4"
    }
    list += add(EngineModule.HS_75, "settings put system peak_refresh_rate 60.0", minSdk = 29) { d, hz ->
      val target = hz.coerceAtMost(d.maxRefreshRateHz)
      "settings put system peak_refresh_rate $target.0"
    }
    list += add(EngineModule.HS_75, "settings put system min_refresh_rate 60.0", minSdk = 30) { d, hz ->
      val target = hz.coerceAtMost(d.maxRefreshRateHz)
      "settings put system min_refresh_rate $target.0"
    }
    list += add(EngineModule.HS_75, "settings put global window_animation_scale 1.0") { _, _ ->
      "settings put global window_animation_scale 0.0"
    }
    list += add(EngineModule.HS_75, "settings put global transition_animation_scale 1.0") { _, _ ->
      "settings put global transition_animation_scale 0.0"
    }
    list += add(EngineModule.HS_75, "settings put global animator_duration_scale 1.0") { _, _ ->
      "settings put global animator_duration_scale 0.0"
    }
    list += add(
      EngineModule.HS_75,
      "settings put system sem_performance_mode 0",
      brands = setOf(DeviceBrand.SAMSUNG),
    ) { _, _ ->
      "settings put system sem_performance_mode 1"
    }
    list += add(
      EngineModule.HS_75,
      "settings put system POWER_PERFORMANCE_MODE_OPEN 0",
      brands = setOf(DeviceBrand.XIAOMI),
    ) { _, _ ->
      "settings put system POWER_PERFORMANCE_MODE_OPEN 1"
    }
    list += add(EngineModule.HS_75, "settings put global power_sounds_enabled 1") { _, _ ->
      "settings put global power_sounds_enabled 0"
    }
    list += add(EngineModule.HS_75, "settings put global charging_sounds_enabled 1") { _, _ ->
      "settings put global charging_sounds_enabled 0"
    }

    // 6. BONECO LENTO (FAST MOVE) (16 comandos)
    list += add(EngineModule.BONECO_LENTO, "settings put system pointer_speed 0") { _, _ ->
      "settings put system pointer_speed 7"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure long_press_timeout 400") { _, _ ->
      "settings put secure long_press_timeout 150"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure multi_press_timeout 300") { _, _ ->
      "settings put secure multi_press_timeout 110"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure back_gesture_inset_scale_left 1.0", minSdk = 29) { _, _ ->
      "settings put secure back_gesture_inset_scale_left 0.25"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure back_gesture_inset_scale_right 1.0", minSdk = 29) { _, _ ->
      "settings put secure back_gesture_inset_scale_right 0.25"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure assist_gesture_enabled 1", minSdk = 28) { _, _ ->
      "settings put secure assist_gesture_enabled 0"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure assist_gesture_silence_alerts_enabled 1", minSdk = 28) { _, _ ->
      "settings put secure assist_gesture_silence_alerts_enabled 0"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure camera_double_tap_power_gesture_disabled 0") { _, _ ->
      "settings put secure camera_double_tap_power_gesture_disabled 1"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure camera_lift_trigger_enabled 1", minSdk = 28) { _, _ ->
      "settings put secure camera_lift_trigger_enabled 0"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure skip_gesture 1", minSdk = 29) { _, _ ->
      "settings put secure skip_gesture 0"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put secure silence_gesture 1", minSdk = 29) { _, _ ->
      "settings put secure silence_gesture 0"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put system screen_off_timeout 60000") { _, _ ->
      "settings put system screen_off_timeout 300000"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put system master_mono 0") { _, _ ->
      "settings put system master_mono 0"
    }
    list += add(EngineModule.BONECO_LENTO, "settings put system haptic_feedback_enabled 1") { _, _ ->
      "settings put system haptic_feedback_enabled 0"
    }
    list += add(
      EngineModule.BONECO_LENTO,
      "settings put system high_frame_rate_mode 0",
      brands = setOf(DeviceBrand.REALME),
    ) { _, _ ->
      "settings put system high_frame_rate_mode 1"
    }
    list += add(
      EngineModule.BONECO_LENTO,
      "settings put global game_genie_performance_mode 0",
      brands = setOf(DeviceBrand.ASUS),
    ) { _, _ ->
      "settings put global game_genie_performance_mode 1"
    }

    // =========================================================================
    // BANCO B: 100 COMANDOS DE DESEMPENHO, CPU/GPU, HZ & FPS
    // =========================================================================

    // 7. BOOST CPU & GPU + CRAVAR 90~100 FPS (25 comandos)
    list += add(EngineModule.BOOST_CPU_GPU, "cmd game mode standard com.dts.freefireth", minSdk = 31, minHz = 90) { _, _ ->
      "cmd game mode performance com.dts.freefireth"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd game mode standard com.dts.freefiremax", minSdk = 31, minHz = 90) { _, _ ->
      "cmd game mode performance com.dts.freefiremax"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd game set --fps 60 com.dts.freefireth", minSdk = 31, minHz = 90) { d, hz ->
      "cmd game set --fps ${hz.coerceAtMost(d.maxRefreshRateHz)} com.dts.freefireth"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd game set --fps 60 com.dts.freefiremax", minSdk = 31, minHz = 90) { d, hz ->
      "cmd game set --fps ${hz.coerceAtMost(d.maxRefreshRateHz)} com.dts.freefiremax"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd game set --downscale 1.0 com.dts.freefireth", minSdk = 31, minHz = 90) { _, _ ->
      "cmd game set --downscale disable com.dts.freefireth"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd game set --downscale 1.0 com.dts.freefiremax", minSdk = 31, minHz = 90) { _, _ ->
      "cmd game set --downscale disable com.dts.freefiremax"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd power set-fixed-performance-mode-enabled false", minSdk = 31, minHz = 90) { _, _ ->
      "cmd power set-fixed-performance-mode-enabled true"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd power set-adaptive-power-saver-enabled true", minSdk = 31, minHz = 90) { _, _ ->
      "cmd power set-adaptive-power-saver-enabled false"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd thermalservice reset", minSdk = 31, minHz = 90) { _, _ ->
      "cmd thermalservice override-status 0"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put system peak_refresh_rate 60.0", minSdk = 31, minHz = 90) { d, hz ->
      "settings put system peak_refresh_rate ${hz.coerceAtMost(d.maxRefreshRateHz)}.0"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put system min_refresh_rate 60.0", minSdk = 31, minHz = 90) { d, hz ->
      "settings put system min_refresh_rate ${hz.coerceAtMost(d.maxRefreshRateHz)}.0"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put system user_refresh_rate 60", minSdk = 31, minHz = 90) { d, hz ->
      "settings put system user_refresh_rate ${hz.coerceAtMost(d.maxRefreshRateHz)}"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global cached_apps_freezer default", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global cached_apps_freezer enabled"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global sustained_performance_mode 0", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global sustained_performance_mode 1"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global low_power 0", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global low_power 0"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global low_power_sticky 0", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global low_power_sticky 0"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global adaptive_battery_management_enabled 1", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global adaptive_battery_management_enabled 0"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global app_auto_restriction_enabled 1", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global app_auto_restriction_enabled 0"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd deviceidle whitelist -com.dts.freefireth", minSdk = 31, minHz = 90) { _, _ ->
      "cmd deviceidle whitelist +com.dts.freefireth"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "cmd deviceidle whitelist -com.dts.freefiremax", minSdk = 31, minHz = 90) { _, _ ->
      "cmd deviceidle whitelist +com.dts.freefiremax"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global power_save_constants null", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global power_save_constants null"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put secure refresh_rate_mode 0", minSdk = 31, minHz = 90) { _, _ ->
      "settings put secure refresh_rate_mode 2"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global angle_gl_driver_all_angle 0", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global angle_gl_driver_all_angle 0"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global updatable_driver_all_apps 0", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global updatable_driver_all_apps 1"
    }
    list += add(EngineModule.BOOST_CPU_GPU, "settings put global game_driver_all_apps 0", minSdk = 31, minHz = 90) { _, _ ->
      "settings put global game_driver_all_apps 1"
    }

    // 8. INTERFACE LEVE & OTIMIZAR TODOS OS APPS (25 comandos)
    list += add(EngineModule.LIGHT_UI, "settings put global window_animation_scale 1.0") { _, _ ->
      "settings put global window_animation_scale 0.0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global transition_animation_scale 1.0") { _, _ ->
      "settings put global transition_animation_scale 0.0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global animator_duration_scale 1.0") { _, _ ->
      "settings put global animator_duration_scale 0.0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global fancy_ime_animations 1") { _, _ ->
      "settings put global fancy_ime_animations 0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global disable_window_blurs 0", minSdk = 31) { _, _ ->
      "settings put global disable_window_blurs 1"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global accessibility_reduce_transparency 0", minSdk = 31) { _, _ ->
      "settings put global accessibility_reduce_transparency 1"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global show_notifications_on_lockscreen 1") { _, _ ->
      "settings put global heads_up_notifications_enabled 0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put secure show_ime_with_hard_keyboard 1") { _, _ ->
      "settings put secure show_ime_with_hard_keyboard 0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put system font_scale 1.0") { _, _ ->
      "settings put system font_scale 0.95"
    }
    list += add(EngineModule.LIGHT_UI, "settings put system status_bar_show_battery_percent 1") { _, _ ->
      "settings put system status_bar_show_battery_percent 1"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global overlay_display_devices null") { _, _ ->
      "settings put global overlay_display_devices null"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global always_finish_activities 0") { _, _ ->
      "settings put global always_finish_activities 0"
    }
    list += add(EngineModule.LIGHT_UI, "pm trim-caches 1G") { _, _ ->
      "pm trim-caches 999G"
    }
    list += add(EngineModule.LIGHT_UI, "pm trim-caches 1G internal") { _, _ ->
      "pm trim-caches 999G internal"
    }
    list += add(EngineModule.LIGHT_UI, "cmd package compile -m speed-profile com.dts.freefireth") { _, _ ->
      "cmd package compile -m speed-profile com.dts.freefireth"
    }
    list += add(EngineModule.LIGHT_UI, "cmd package compile -m speed-profile com.dts.freefiremax") { _, _ ->
      "cmd package compile -m speed-profile com.dts.freefiremax"
    }
    list += add(EngineModule.LIGHT_UI, "cmd package bg-dexopt-job", minSdk = 28) { _, _ ->
      "cmd package bg-dexopt-job"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global enable_freeform_support 0") { _, _ ->
      "settings put global enable_freeform_support 0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global force_resizable_activities 0") { _, _ ->
      "settings put global force_resizable_activities 0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put secure night_display_activated 0") { _, _ ->
      "settings put secure night_display_activated 0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put secure night_display_auto_mode 1") { _, _ ->
      "settings put secure night_display_auto_mode 0"
    }
    list += add(EngineModule.LIGHT_UI, "settings put secure icon_blacklist null") { _, _ ->
      "settings put secure icon_blacklist rotate"
    }
    list += add(EngineModule.LIGHT_UI, "settings put global zen_mode 0") { _, _ ->
      "settings put global zen_mode 1"
    }
    list += add(EngineModule.LIGHT_UI, "wm disable-blur 0", minSdk = 31) { _, _ ->
      "wm disable-blur 1"
    }
    list += add(EngineModule.LIGHT_UI, "wm tracing stop") { _, _ ->
      "wm tracing stop"
    }

    // 9. JOGAR SEM QUEDA DE TAXA DE QUADROS (25 comandos)
    list += add(EngineModule.NO_FRAME_DROP, "am kill-all") { _, _ ->
      "am kill-all"
    }
    list += add(EngineModule.NO_FRAME_DROP, "cmd activity idle-maintenance") { _, _ ->
      "cmd activity idle-maintenance"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global app_standby_enabled 1") { _, _ ->
      "settings put global app_standby_enabled 1"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global forced_app_standby_enabled 0") { _, _ ->
      "settings put global forced_app_standby_enabled 1"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global forced_app_standby_for_small_battery_enabled 0", minSdk = 28) { _, _ ->
      "settings put global forced_app_standby_for_small_battery_enabled 1"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global wifi_sleep_policy 0") { _, _ ->
      "settings put global wifi_sleep_policy 2"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global wifi_scan_always_enabled 1") { _, _ ->
      "settings put global wifi_scan_always_enabled 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global ble_scan_always_enabled 1") { _, _ ->
      "settings put global ble_scan_always_enabled 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global network_recommendations_enabled 1") { _, _ ->
      "settings put global network_recommendations_enabled 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global netstats_enabled 1") { _, _ ->
      "settings put global netstats_enabled 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global wifi_networks_available_notification_on 1") { _, _ ->
      "settings put global wifi_networks_available_notification_on 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global wifi_wakeup_enabled 1") { _, _ ->
      "settings put global wifi_wakeup_enabled 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global mobile_data_always_on 1") { _, _ ->
      "settings put global mobile_data_always_on 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global captive_portal_mode 1") { _, _ ->
      "settings put global captive_portal_mode 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global battery_saver_constants null") { _, _ ->
      "settings put global battery_saver_constants advertise_is_enabled=false"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global low_power 0") { _, _ ->
      "settings put global low_power 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global adaptive_battery_management_enabled 1") { _, _ ->
      "settings put global adaptive_battery_management_enabled 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global background_data 1") { _, _ ->
      "settings put global background_data 1"
    }
    list += add(EngineModule.NO_FRAME_DROP, "cmd deviceidle whitelist -com.dts.freefireth") { _, _ ->
      "cmd deviceidle whitelist +com.dts.freefireth"
    }
    list += add(EngineModule.NO_FRAME_DROP, "cmd deviceidle whitelist -com.dts.freefiremax") { _, _ ->
      "cmd deviceidle whitelist +com.dts.freefiremax"
    }
    list += add(EngineModule.NO_FRAME_DROP, "cmd power set-adaptive-power-saver-enabled true", minSdk = 29) { _, _ ->
      "cmd power set-adaptive-power-saver-enabled false"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global zram_enabled 1") { _, _ ->
      "settings put global zram_enabled 1"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global ram_expand_size 0", minSdk = 31) { _, _ ->
      "settings put global ram_expand_size 0"
    }
    list += add(EngineModule.NO_FRAME_DROP, "settings put global stay_on_while_plugged_in 0") { _, _ ->
      "settings put global stay_on_while_plugged_in 3"
    }
    list += add(EngineModule.NO_FRAME_DROP, "pm trim-caches 512M") { _, _ ->
      "pm trim-caches 999G"
    }

    // 10. ACELERAÇÃO EXTREMA DO SISTEMA ANDROID (25 comandos)
    list += add(EngineModule.EXTREME_ACCEL, "settings put global activity_starts_logging_enabled 1") { _, _ ->
      "settings put global activity_starts_logging_enabled 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global sys_traced 1") { _, _ ->
      "settings put global sys_traced 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put secure send_action_app_error 1") { _, _ ->
      "settings put secure send_action_app_error 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global send_action_app_error 1") { _, _ ->
      "settings put global send_action_app_error 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global upload_apk_enable 1") { _, _ ->
      "settings put global upload_apk_enable 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global verifier_verify_adb_installs 1") { _, _ ->
      "settings put global verifier_verify_adb_installs 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global package_verifier_enable 1") { _, _ ->
      "settings put global package_verifier_enable 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global wait_for_debugger 0") { _, _ ->
      "settings put global wait_for_debugger 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global bugreport_in_power_menu 1") { _, _ ->
      "settings put global bugreport_in_power_menu 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global anr_show_background 1") { _, _ ->
      "settings put global anr_show_background 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global show_first_crash_dialog_dev_option 1") { _, _ ->
      "settings put global show_first_crash_dialog_dev_option 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global dropbox_age_seconds 259200") { _, _ ->
      "settings put global dropbox_age_seconds 60"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global dropbox_max_files 1000") { _, _ ->
      "settings put global dropbox_max_files 10"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global wtf_is_fatal 0") { _, _ ->
      "settings put global wtf_is_fatal 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global enable_diskstats_logging 1") { _, _ ->
      "settings put global enable_diskstats_logging 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global logd_size 262144") { _, _ ->
      "settings put global logd_size 65536"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global sqlite_compatibility_wal_flags null") { _, _ ->
      "settings put global sqlite_compatibility_wal_flags truncate"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put secure backup_enabled 1") { _, _ ->
      "settings put secure backup_enabled 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global auto_sync 1") { _, _ ->
      "settings put global auto_sync 0"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global auto_time 1") { _, _ ->
      "settings put global auto_time 1"
    }
    list += add(EngineModule.EXTREME_ACCEL, "settings put global development_settings_enabled 1") { _, _ ->
      "settings put global development_settings_enabled 1"
    }
    list += add(EngineModule.EXTREME_ACCEL, "cmd shortcut reset-all-throttling") { _, _ ->
      "cmd shortcut reset-all-throttling"
    }
    list += add(EngineModule.EXTREME_ACCEL, "cmd package trim-caches 512M") { _, _ ->
      "pm trim-caches 999G"
    }
    list += add(EngineModule.EXTREME_ACCEL, "am kill-all") { _, _ ->
      "am kill-all"
    }
    list += add(EngineModule.EXTREME_ACCEL, "wm tracing stop") { _, _ ->
      "wm tracing stop"
    }

    return list
  }
}
