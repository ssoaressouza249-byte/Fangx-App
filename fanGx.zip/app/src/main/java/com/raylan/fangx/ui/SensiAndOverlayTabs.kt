package com.raylan.fangx.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FangxBorderSubtle
import com.example.ui.theme.FangxCyan
import com.example.ui.theme.FangxDeepBlack
import com.example.ui.theme.FangxGraphite
import com.example.ui.theme.FangxGraphiteElevated
import com.example.ui.theme.FangxNeonGreen
import com.example.ui.theme.FangxNeonRed
import com.example.ui.theme.FangxTextPrimary
import com.example.ui.theme.FangxTextSecondary
import com.raylan.fangx.DeviceInfo
import com.raylan.fangx.SensitivityProfile
import com.raylan.fangx.overlay.CrosshairColorOption
import com.raylan.fangx.overlay.CrosshairConfig
import com.raylan.fangx.overlay.CrosshairStyle

@Composable
fun SensitivityGeneratorTab(
  profile: SensitivityProfile,
  deviceInfo: DeviceInfo,
  onGenerateNew: () -> Unit,
  onCopyAll: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Card(
      colors = CardDefaults.cardColors(containerColor = FangxGraphite),
      border = BorderStroke(1.dp, FangxCyan.copy(alpha = 0.6f)),
      shape = RoundedCornerShape(14.dp),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Tune, contentDescription = null, tint = FangxCyan)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "GERADOR DE SENSI INFINITA",
              color = FangxCyan,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
            )
          }
          Text(
            text = "100 – 200",
            color = FangxNeonRed,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.sp,
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        val items =
          listOf(
            "Geral" to profile.geral,
            "Ponto Vermelho" to profile.pontoVermelho,
            "Mira 2x" to profile.mira2x,
            "Mira 4x" to profile.mira4x,
            "AWM" to profile.awm,
            "Olhadinha" to profile.olhadinha,
          )

        items.forEach { (label, value) ->
          SensitivityBarRow(label = label, value = value)
          Spacer(modifier = Modifier.height(10.dp))
        }

        Spacer(modifier = Modifier.height(6.dp))

        Button(
          onClick = onGenerateNew,
          colors = ButtonDefaults.buttonColors(containerColor = FangxCyan, contentColor = FangxDeepBlack),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().height(52.dp).testTag("generate_sensi_button"),
        ) {
          Icon(Icons.Filled.AutoAwesome, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "GERAR NOVA SENSI (100 - 200)",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp,
          )
        }
      }
    }

    Card(
      colors = CardDefaults.cardColors(containerColor = FangxGraphite),
      border = BorderStroke(1.dp, FangxBorderSubtle),
      shape = RoundedCornerShape(14.dp),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "Resolução & DPI Recomendado para o seu ${deviceInfo.model}",
          color = FangxCyan,
          fontFamily = FontFamily.Default,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          DpiStatTile(
            label = "DPI IDEAL",
            value = "${profile.recommendedDpi}",
            modifier = Modifier.weight(1f),
          )
          DpiStatTile(
            label = "BOTÃO ATIRAR",
            value = "${profile.recommendedFireButtonPercent}%",
            modifier = Modifier.weight(1f),
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Tela calibrada: ${profile.recommendedResolutionLabel}",
          color = FangxTextSecondary,
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
        )
      }
    }

    Card(
      colors = CardDefaults.cardColors(containerColor = FangxGraphite),
      border = BorderStroke(1.dp, FangxNeonRed.copy(alpha = 0.5f)),
      shape = RoundedCornerShape(14.dp),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.TipsAndUpdates, contentDescription = null, tint = FangxNeonRed)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Dicas de Puxada Calibradas",
            color = FangxTextPrimary,
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        profile.dragTips.forEachIndexed { idx, tip ->
          Text(
            text = "${idx + 1}. $tip",
            color = FangxTextSecondary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
            modifier = Modifier.padding(bottom = 6.dp),
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
          onClick = onCopyAll,
          border = BorderStroke(1.5.dp, FangxCyan),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().height(50.dp).testTag("copy_sensi_tips_button"),
        ) {
          Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = FangxCyan)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "COPIAR SENSI & DICAS",
            color = FangxCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
          )
        }
      }
    }
  }
}

@Composable
private fun SensitivityBarRow(label: String, value: Int) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = label,
        color = FangxTextPrimary,
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
      )
      Text(
        text = value.toString(),
        color = FangxCyan,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Black,
        fontSize = 15.sp,
      )
    }
    Spacer(modifier = Modifier.height(4.dp))
    LinearProgressIndicator(
      progress = { ((value - 100f) / 100f).coerceIn(0f, 1f) },
      modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
      color = if (value >= 180) FangxNeonRed else FangxCyan,
      trackColor = FangxGraphiteElevated,
    )
  }
}

@Composable
private fun DpiStatTile(label: String, value: String, modifier: Modifier = Modifier) {
  Column(
    modifier =
      modifier
        .clip(RoundedCornerShape(10.dp))
        .background(FangxGraphiteElevated)
        .border(1.dp, FangxBorderSubtle, RoundedCornerShape(10.dp))
        .padding(12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Text(
      text = label,
      color = FangxTextSecondary,
      fontFamily = FontFamily.Monospace,
      fontSize = 10.sp,
    )
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = value,
      color = FangxCyan,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Black,
      fontSize = 20.sp,
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FloatingCrosshairTab(
  config: CrosshairConfig,
  hasOverlayPermission: Boolean,
  onToggleOverlayService: () -> Unit,
  onToggleCrosshairVisibility: () -> Unit,
  onSelectStyle: (CrosshairStyle) -> Unit,
  onSelectColor: (CrosshairColorOption) -> Unit,
  onSizeChange: (Float) -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Card(
      colors = CardDefaults.cardColors(containerColor = FangxGraphite),
      border =
        BorderStroke(
          1.5.dp,
          if (config.isOverlayActive) FangxNeonGreen else FangxCyan.copy(alpha = 0.6f),
        ),
      shape = RoundedCornerShape(14.dp),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(Icons.Filled.Layers, contentDescription = null, tint = FangxCyan)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "PAINEL FLUTUANTE GAMER",
                color = FangxTextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
              )
              Text(
                text =
                  if (!hasOverlayPermission) "Permissão 'Sobrepor a outros apps' necessária"
                  else if (config.isOverlayActive) "Ativo sobre o jogo • Mira central ligada"
                  else "Pronto para iniciar no Free Fire",
                color = if (config.isOverlayActive) FangxNeonGreen else FangxTextSecondary,
                fontSize = 11.sp,
              )
            }
          }
          Switch(
            checked = config.isOverlayActive,
            onCheckedChange = { onToggleOverlayService() },
            modifier = Modifier.testTag("toggle_overlay_service_switch"),
            colors =
              SwitchDefaults.colors(
                checkedThumbColor = FangxDeepBlack,
                checkedTrackColor = FangxNeonGreen,
                uncheckedThumbColor = FangxTextSecondary,
                uncheckedTrackColor = FangxDeepBlack,
              ),
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Live Crosshair Preview Canvas
        Box(
          modifier =
            Modifier
              .fillMaxWidth()
              .height(150.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(FangxDeepBlack)
              .border(1.dp, FangxBorderSubtle, RoundedCornerShape(12.dp)),
          contentAlignment = Alignment.Center,
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val gridStep = 24.dp.toPx()
            var x = 0f
            while (x < w) {
              drawLine(FangxBorderSubtle.copy(alpha = 0.35f), Offset(x, 0f), Offset(x, h), 1f)
              x += gridStep
            }
            var y = 0f
            while (y < h) {
              drawLine(FangxBorderSubtle.copy(alpha = 0.35f), Offset(0f, y), Offset(w, y), 1f)
              y += gridStep
            }

            if (config.showCrosshair) {
              val cx = w / 2f
              val cy = h / 2f
              val radius = config.sizeDp.dp.toPx() / 2f
              val stroke = config.strokeWidthDp.dp.toPx()
              val color = Color(config.colorOption.argb)
              val glow = color.copy(alpha = 0.45f)

              when (config.style) {
                CrosshairStyle.LASER_DOT -> {
                  drawCircle(glow, radius = (radius * 0.42f).coerceAtLeast(6f), center = Offset(cx, cy))
                  drawCircle(color, radius = (radius * 0.22f).coerceAtLeast(3.5f), center = Offset(cx, cy))
                }
                CrosshairStyle.CROSS -> {
                  val gap = radius * 0.25f
                  drawLine(color, Offset(cx - radius, cy), Offset(cx - gap, cy), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx + gap, cy), Offset(cx + radius, cy), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx, cy - radius), Offset(cx, cy - gap), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx, cy + gap), Offset(cx, cy + radius), stroke, StrokeCap.Round)
                  drawCircle(color, stroke * 0.9f, Offset(cx, cy))
                }
                CrosshairStyle.TACTICAL_RETICLE -> {
                  val gap = radius * 0.35f
                  drawCircle(color, radius * 0.7f, Offset(cx, cy), style = Stroke(stroke))
                  drawLine(color, Offset(cx - radius, cy), Offset(cx - gap, cy), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx + gap, cy), Offset(cx + radius, cy), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx, cy - radius), Offset(cx, cy - gap), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx, cy + gap), Offset(cx, cy + radius), stroke, StrokeCap.Round)
                  drawCircle(color, stroke, Offset(cx, cy))
                }
                CrosshairStyle.X_SNIPER -> {
                  val d = radius * 0.75f
                  val g = radius * 0.25f
                  drawLine(color, Offset(cx - d, cy - d), Offset(cx - g, cy - g), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx + g, cy + g), Offset(cx + d, cy + d), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx + d, cy - d), Offset(cx + g, cy - g), stroke, StrokeCap.Round)
                  drawLine(color, Offset(cx - g, cy + g), Offset(cx - d, cy + d), stroke, StrokeCap.Round)
                  drawCircle(color, stroke * 0.85f, Offset(cx, cy))
                }
                CrosshairStyle.PRO_CIRCLE -> {
                  drawCircle(color, radius * 0.82f, Offset(cx, cy), style = Stroke(stroke))
                  drawCircle(color, (radius * 0.16f).coerceAtLeast(3f), Offset(cx, cy))
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CenterFocusStrong, contentDescription = null, tint = FangxCyan)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Exibir Mira Central",
              color = FangxTextPrimary,
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp,
            )
          }
          Switch(
            checked = config.showCrosshair,
            onCheckedChange = { onToggleCrosshairVisibility() },
            colors =
              SwitchDefaults.colors(
                checkedThumbColor = FangxDeepBlack,
                checkedTrackColor = FangxCyan,
              ),
          )
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "ESTILO DA MIRA",
          color = FangxTextSecondary,
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          CrosshairStyle.entries.forEach { style ->
            val selected = config.style == style
            Box(
              modifier =
                Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (selected) FangxCyan.copy(alpha = 0.16f) else FangxGraphiteElevated)
                  .border(
                    1.dp,
                    if (selected) FangxCyan else FangxBorderSubtle,
                    RoundedCornerShape(8.dp),
                  )
                  .clickable { onSelectStyle(style) }
                  .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
              Text(
                text = style.label,
                color = if (selected) FangxCyan else FangxTextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = "COR DO RETÍCULO",
          color = FangxTextSecondary,
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          CrosshairColorOption.entries.forEach { option ->
            val selected = config.colorOption == option
            Box(
              modifier =
                Modifier
                  .size(48.dp)
                  .clip(CircleShape)
                  .background(Color(option.argb))
                  .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) FangxTextPrimary else FangxBorderSubtle,
                    shape = CircleShape,
                  )
                  .clickable { onSelectColor(option) }
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = "TAMANHO DA MIRA",
            color = FangxTextSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "${config.sizeDp.toInt()} dp",
            color = FangxCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
          )
        }
        Slider(
          value = config.sizeDp,
          onValueChange = onSizeChange,
          valueRange = 12f..48f,
          colors =
            SliderDefaults.colors(
              thumbColor = FangxCyan,
              activeTrackColor = FangxCyan,
              inactiveTrackColor = FangxGraphiteElevated,
            ),
        )
      }
    }
  }
}
