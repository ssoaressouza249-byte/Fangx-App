package com.raylan.fangx

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.example.BuildConfig
import com.example.R

data class SecurityStatus(
  val isIntact: Boolean,
  val violationReason: String? = null,
)

object SecurityGuard {

  const val EXPECTED_PACKAGE_NAME = "com.raylan.fangx"
  const val EXPECTED_APP_LABEL = "Fangx"
  const val EXPECTED_AUTHOR = "Raylan"

  const val TAMPER_MESSAGE =
    "DESINSTALAR APP - POIS ESSE NÃO É A VERSÃO OFICIAL DO CRIADOR. ESTA VERSÃO FOI MODIFICADA. POR FAVOR ABRA O NOSSO DISCORD OFICIAL E ADQUIRA A VERSÃO VIP OFICIAL."

  fun verifyIntegrity(context: Context): SecurityStatus {
    return runCatching {
        val currentPackage = context.packageName
        if (currentPackage != EXPECTED_PACKAGE_NAME) {
          return@runCatching SecurityStatus(
            isIntact = false,
            violationReason = "Pacote alterado: $currentPackage",
          )
        }

        if (BuildConfig.APPLICATION_ID != EXPECTED_PACKAGE_NAME) {
          return@runCatching SecurityStatus(
            isIntact = false,
            violationReason = "ApplicationId inválido: ${BuildConfig.APPLICATION_ID}",
          )
        }

        val pmLabel =
          runCatching {
              val pm = context.packageManager
              val appInfo =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                  pm.getApplicationInfo(
                    currentPackage,
                    android.content.pm.PackageManager.ApplicationInfoFlags.of(0L),
                  )
                } else {
                  @Suppress("DEPRECATION")
                  pm.getApplicationInfo(currentPackage, 0)
                }
              pm.getApplicationLabel(appInfo).toString()
            }
            .getOrDefault(context.getString(R.string.app_name))

        if (pmLabel != EXPECTED_APP_LABEL) {
          return@runCatching SecurityStatus(
            isIntact = false,
            violationReason = "Rótulo do app modificado: $pmLabel",
          )
        }

        val stringResName =
          runCatching { context.getString(R.string.app_name) }.getOrDefault("")
        if (stringResName != EXPECTED_APP_LABEL) {
          return@runCatching SecurityStatus(
            isIntact = false,
            violationReason = "Recurso app_name alterado: $stringResName",
          )
        }

        val guardClassOk = SecurityGuard::class.java.simpleName == "SecurityGuard"
        val engineClassOk = MassiveCommandEngine::class.java.simpleName == "MassiveCommandEngine"
        val modulesOk = MassiveCommandEngine.verifyInternalModuleIntegrity()
        val creditsRes =
          runCatching { context.getString(R.string.official_credits) }.getOrDefault("")
        val authorIntact = creditsRes.contains(EXPECTED_AUTHOR)

        if (!guardClassOk || !engineClassOk || !modulesOk || !authorIntact) {
          return@runCatching SecurityStatus(
            isIntact = false,
            violationReason = "Assinatura de módulos internos violada",
          )
        }

        // Nota: Certificados de debug não são bloqueados para permitir builds via GitHub Actions.
        SecurityStatus(isIntact = true)
      }
      .getOrElse { err ->
        SecurityStatus(
          isIntact = false,
          violationReason = "Falha na verificação de integridade: ${err.message}",
        )
      }
  }

  fun launchSelfUninstall(context: Context) {
    runCatching {
      val intent =
        Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(intent)
    }
  }
}
