package com.raylan.fangx.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FangxOverlayService : Service() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private var collectJob: Job? = null
  private var windowManager: WindowManager? = null
  private var crosshairView: CrosshairOverlayView? = null
  private var panelView: View? = null
  private var isExpanded = false

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    startForegroundSafe()
    if (!Settings.canDrawOverlays(this)) {
      OverlayStateStore.update { it.copy(isOverlayActive = false) }
      stopSelf()
      return
    }
    setupOverlays()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP_OVERLAY) {
      OverlayStateStore.update { it.copy(isOverlayActive = false) }
      stopSelf()
      return START_NOT_STICKY
    }
    return START_STICKY
  }

  override fun onDestroy() {
    runCatching { collectJob?.cancel() }
    runCatching { serviceScope.cancel() }
    runCatching {
      crosshairView?.let { windowManager?.removeViewImmediate(it) }
      crosshairView = null
    }
    runCatching {
      panelView?.let { windowManager?.removeViewImmediate(it) }
      panelView = null
    }
    OverlayStateStore.update { it.copy(isOverlayActive = false) }
    super.onDestroy()
  }

  private fun startForegroundSafe() {
    runCatching {
      val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      val channel =
        NotificationChannel(
            CHANNEL_ID,
            getString(R.string.overlay_notification_channel),
            NotificationManager.IMPORTANCE_LOW,
          )
          .apply { setShowBadge(false) }
      manager?.createNotificationChannel(channel)

      val openAppIntent =
        Intent(this, MainActivity::class.java).apply {
          flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
      val pendingIntent =
        PendingIntent.getActivity(
          this,
          0,
          openAppIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

      val notification =
        Notification.Builder(this, CHANNEL_ID)
          .setContentTitle(getString(R.string.overlay_notification_title))
          .setContentText(getString(R.string.overlay_notification_text))
          .setSmallIcon(R.mipmap.ic_launcher_round)
          .setContentIntent(pendingIntent)
          .setOngoing(true)
          .build()

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        startForeground(
          NOTIFICATION_ID,
          notification,
          ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
      } else {
        startForeground(NOTIFICATION_ID, notification)
      }
    }
  }

  private fun setupOverlays() {
    runCatching {
      val wm = getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
      windowManager = wm

      val crosshair = CrosshairOverlayView(this)
      val crosshairParams =
        WindowManager.LayoutParams(
            dp(96),
            dp(96),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
              WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
              WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
          )
          .apply { gravity = Gravity.CENTER }
      wm.addView(crosshair, crosshairParams)
      crosshairView = crosshair

      val panelParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
              WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
          )
          .apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(140)
          }
      val floatingPanel = buildFloatingControlView(wm, panelParams)
      wm.addView(floatingPanel, panelParams)
      panelView = floatingPanel

      OverlayStateStore.update { it.copy(isOverlayActive = true) }

      collectJob =
        serviceScope.launch {
          OverlayStateStore.config.collectLatest { config ->
            runCatching {
              crosshairView?.updateConfig(config)
              crosshairView?.visibility = if (config.showCrosshair) View.VISIBLE else View.GONE
            }
          }
        }
    }
  }

  @SuppressLint("ClickableViewAccessibility")
  private fun buildFloatingControlView(
    wm: WindowManager,
    params: WindowManager.LayoutParams,
  ): View {
    val root =
      LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background =
          GradientDrawable().apply {
            setColor(Color.parseColor("#E6090A0F"))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), Color.parseColor("#00F0FF"))
          }
        setPadding(dp(10), dp(8), dp(10), dp(8))
      }

    val expandedContainer =
      LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        visibility = View.GONE
        setPadding(0, dp(8), 0, 0)
      }

    val headerPill =
      TextView(this).apply {
        text = "FANGX • HUD"
        setTextColor(Color.parseColor("#00F0FF"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
      }

    var initialX = 0
    var initialY = 0
    var initialTouchX = 0f
    var initialTouchY = 0f
    var moved = false

    headerPill.setOnTouchListener { _, event ->
      when (event.action) {
        MotionEvent.ACTION_DOWN -> {
          initialX = params.x
          initialY = params.y
          initialTouchX = event.rawX
          initialTouchY = event.rawY
          moved = false
          true
        }
        MotionEvent.ACTION_MOVE -> {
          val dx = (event.rawX - initialTouchX).toInt()
          val dy = (event.rawY - initialTouchY).toInt()
          if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
          params.x = initialX + dx
          params.y = initialY + dy
          runCatching { wm.updateViewLayout(root, params) }
          true
        }
        MotionEvent.ACTION_UP -> {
          if (!moved) {
            isExpanded = !isExpanded
            expandedContainer.visibility = if (isExpanded) View.VISIBLE else View.GONE
          }
          true
        }
        else -> false
      }
    }

    fun actionChip(label: String, strokeColor: String = "#232A3E", textColor: String = "#F2F6FF", onClick: () -> Unit): TextView {
      return TextView(this).apply {
        text = label
        setTextColor(Color.parseColor(textColor))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
        background =
          GradientDrawable().apply {
            setColor(Color.parseColor("#131620"))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.parseColor(strokeColor))
          }
        setPadding(dp(10), dp(6), dp(10), dp(6))
        val lp =
          LinearLayout.LayoutParams(
              LinearLayout.LayoutParams.MATCH_PARENT,
              LinearLayout.LayoutParams.WRAP_CONTENT,
            )
            .apply { topMargin = dp(5) }
        layoutParams = lp
        setOnClickListener { runCatching { onClick() } }
      }
    }

    expandedContainer.addView(
      actionChip("Estilo da Mira (Trocar)", "#00F0FF", "#00F0FF") {
        OverlayStateStore.cycleStyle()
      }
    )
    expandedContainer.addView(
      actionChip("Cor da Mira (Trocar)", "#00F0FF", "#F2F6FF") {
        OverlayStateStore.cycleColor()
      }
    )
    expandedContainer.addView(
      actionChip("Tamanho (+4dp)", "#232A3E", "#F2F6FF") {
        OverlayStateStore.update { c ->
          val next = if (c.sizeDp >= 44f) 14f else c.sizeDp + 4f
          c.copy(sizeDp = next)
        }
      }
    )
    expandedContainer.addView(
      actionChip("Alternar Mira ON/OFF", "#232A3E", "#00E676") {
        OverlayStateStore.update { it.copy(showCrosshair = !it.showCrosshair) }
      }
    )
    expandedContainer.addView(
      actionChip("Fechar Painel Flutuante", "#FF1E42", "#FF1E42") {
        OverlayStateStore.update { it.copy(isOverlayActive = false) }
        stopSelf()
      }
    )

    val creditsFooter =
      TextView(this).apply {
        text = getString(R.string.official_credits)
        setTextColor(Color.parseColor("#8E9AB5"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        setTypeface(android.graphics.Typeface.MONOSPACE)
        setPadding(0, dp(6), 0, 0)
      }
    expandedContainer.addView(creditsFooter)

    root.addView(headerPill)
    root.addView(expandedContainer)
    return root
  }

  private fun dp(value: Int): Int {
    return TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value.toFloat(),
        resources.displayMetrics,
      )
      .toInt()
  }

  companion object {
    private const val CHANNEL_ID = "fangx_overlay_channel"
    private const val NOTIFICATION_ID = 9042
    const val ACTION_STOP_OVERLAY = "com.raylan.fangx.action.STOP_OVERLAY"

    fun start(context: Context) {
      runCatching {
        val intent = Intent(context, FangxOverlayService::class.java)
        context.startForegroundService(intent)
      }
    }

    fun stop(context: Context) {
      runCatching {
        context.stopService(Intent(context, FangxOverlayService::class.java))
      }
    }
  }
}

class CrosshairOverlayView(context: Context) : View(context) {

  private var currentConfig = CrosshairConfig()

  private val glowPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeCap = Paint.Cap.ROUND
    }

  private val corePaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeCap = Paint.Cap.ROUND
    }

  private val dotPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

  fun updateConfig(config: CrosshairConfig) {
    currentConfig = config
    invalidate()
  }

  override fun onDraw(canvas: Canvas) {
    super.onDraw(canvas)
    val cx = width / 2f
    val cy = height / 2f
    val density = resources.displayMetrics.density
    val radius = (currentConfig.sizeDp * density) / 2f
    val stroke = currentConfig.strokeWidthDp * density
    val color = currentConfig.colorOption.argb

    glowPaint.color = Color.argb(120, Color.red(color), Color.green(color), Color.blue(color))
    glowPaint.strokeWidth = stroke * 2.2f

    corePaint.color = color
    corePaint.strokeWidth = stroke

    dotPaint.color = color

    when (currentConfig.style) {
      CrosshairStyle.LASER_DOT -> {
        dotPaint.color = Color.argb(90, Color.red(color), Color.green(color), Color.blue(color))
        canvas.drawCircle(cx, cy, (radius * 0.42f).coerceAtLeast(6f), dotPaint)
        dotPaint.color = color
        canvas.drawCircle(cx, cy, (radius * 0.22f).coerceAtLeast(3.5f), dotPaint)
      }
      CrosshairStyle.CROSS -> {
        val gap = radius * 0.25f
        listOf(glowPaint, corePaint).forEach { p ->
          canvas.drawLine(cx - radius, cy, cx - gap, cy, p)
          canvas.drawLine(cx + gap, cy, cx + radius, cy, p)
          canvas.drawLine(cx, cy - radius, cx, cy - gap, p)
          canvas.drawLine(cx, cy + gap, cx, cy + radius, p)
        }
        canvas.drawCircle(cx, cy, stroke * 0.9f, dotPaint)
      }
      CrosshairStyle.TACTICAL_RETICLE -> {
        val gap = radius * 0.35f
        listOf(glowPaint, corePaint).forEach { p ->
          canvas.drawCircle(cx, cy, radius * 0.7f, p)
          canvas.drawLine(cx - radius, cy, cx - gap, cy, p)
          canvas.drawLine(cx + gap, cy, cx + radius, cy, p)
          canvas.drawLine(cx, cy - radius, cx, cy - gap, p)
          canvas.drawLine(cx, cy + gap, cx, cy + radius, p)
        }
        canvas.drawCircle(cx, cy, stroke, dotPaint)
      }
      CrosshairStyle.X_SNIPER -> {
        val d = radius * 0.75f
        val g = radius * 0.25f
        listOf(glowPaint, corePaint).forEach { p ->
          canvas.drawLine(cx - d, cy - d, cx - g, cy - g, p)
          canvas.drawLine(cx + g, cy + g, cx + d, cy + d, p)
          canvas.drawLine(cx + d, cy - d, cx + g, cy - g, p)
          canvas.drawLine(cx - g, cy + g, cx - d, cy + d, p)
        }
        canvas.drawCircle(cx, cy, stroke * 0.85f, dotPaint)
      }
      CrosshairStyle.PRO_CIRCLE -> {
        listOf(glowPaint, corePaint).forEach { p ->
          canvas.drawCircle(cx, cy, radius * 0.82f, p)
        }
        canvas.drawCircle(cx, cy, (radius * 0.16f).coerceAtLeast(3f), dotPaint)
      }
    }
  }
}
