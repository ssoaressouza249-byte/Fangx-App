package com.raylan.fangx

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import moe.shizuku.server.IShizukuService
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

enum class ShizukuConnectionState(val label: String) {
  CONNECTED("Shizuku Conectado"),
  NEEDS_PERMISSION("Shizuku Sem Permissão"),
  NOT_RUNNING("Shizuku Inativo"),
  NOT_INSTALLED("Shizuku Não Instalado"),
}

data class CommandExecutionResult(
  val success: Boolean,
  val output: String,
)

object ShizukuBreventBridge {

  const val SHIZUKU_PERMISSION_REQUEST_CODE = 7701

  fun getShizukuState(context: Context): ShizukuConnectionState {
    return runCatching {
        val installed =
          DeviceTelemetryDetector.isPackageInstalled(context, DeviceTelemetryDetector.PKG_SHIZUKU)
        if (!installed) {
          return@runCatching ShizukuConnectionState.NOT_INSTALLED
        }
        if (!Shizuku.pingBinder()) {
          return@runCatching ShizukuConnectionState.NOT_RUNNING
        }
        val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        if (granted) {
          ShizukuConnectionState.CONNECTED
        } else {
          ShizukuConnectionState.NEEDS_PERMISSION
        }
      }
      .getOrDefault(ShizukuConnectionState.NOT_RUNNING)
  }

  fun requestShizukuPermission(): Boolean {
    return runCatching {
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
          Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
          true
        } else {
          false
        }
      }
      .getOrDefault(false)
  }

  suspend fun executeCommandViaShizuku(command: String): CommandExecutionResult =
    withContext(Dispatchers.IO) {
      runCatching {
          val binder = Shizuku.getBinder()
            ?: return@runCatching CommandExecutionResult(false, "Binder Shizuku indisponível")
          val service = IShizukuService.Stub.asInterface(binder)
            ?: return@runCatching CommandExecutionResult(false, "Serviço Shizuku nulo")
          val process = service.newProcess(arrayOf("sh", "-c", command), null, null)
          val stdout =
            runCatching {
                ParcelFileDescriptor.AutoCloseInputStream(process.inputStream).use { stream ->
                  BufferedReader(InputStreamReader(stream)).readText().trim()
                }
              }
              .getOrDefault("")
          val stderr =
            runCatching {
                ParcelFileDescriptor.AutoCloseInputStream(process.errorStream).use { stream ->
                  BufferedReader(InputStreamReader(stream)).readText().trim()
                }
              }
              .getOrDefault("")
          val exitCode = runCatching { process.waitFor() }.getOrDefault(-1)
          runCatching { process.destroy() }
          val combined = listOf(stdout, stderr).filter { it.isNotBlank() }.joinToString(" | ")
          CommandExecutionResult(
            success = exitCode == 0,
            output = if (combined.isNotBlank()) combined else "exit=$exitCode",
          )
        }
        .getOrElse { error ->
          CommandExecutionResult(false, error.message ?: "Erro ao executar via Shizuku")
        }
    }

  fun copyCommandsToClipboard(context: Context, label: String, commands: List<String>): Boolean {
    return runCatching {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val payload = commands.joinToString(separator = "\n")
        clipboard?.setPrimaryClip(ClipData.newPlainText(label, payload))
        clipboard != null
      }
      .getOrDefault(false)
  }

  fun copyTextToClipboard(context: Context, label: String, text: String): Boolean {
    return runCatching {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText(label, text))
        clipboard != null
      }
      .getOrDefault(false)
  }

  fun launchApp(context: Context, packageName: String): Boolean {
    return runCatching {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
          launchIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(launchIntent)
          true
        } else {
          false
        }
      }
      .getOrDefault(false)
  }
}
