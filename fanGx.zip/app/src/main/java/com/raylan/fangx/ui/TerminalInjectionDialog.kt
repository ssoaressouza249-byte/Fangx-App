package com.raylan.fangx.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.FangxBorderSubtle
import com.example.ui.theme.FangxCyan
import com.example.ui.theme.FangxDeepBlack
import com.example.ui.theme.FangxGraphite
import com.example.ui.theme.FangxGraphiteElevated
import com.example.ui.theme.FangxNeonGreen
import com.example.ui.theme.FangxNeonRed
import com.example.ui.theme.FangxTextPrimary
import com.example.ui.theme.FangxTextSecondary
import com.raylan.fangx.TerminalMode
import com.raylan.fangx.TerminalSessionState

@Composable
fun TerminalInjectionDialog(
  terminal: TerminalSessionState,
  onOpenBrevent: () -> Unit,
  onOpenGame: () -> Unit,
  onDismiss: () -> Unit,
) {
  if (!terminal.isVisible) return

  val listState = rememberLazyListState()
  LaunchedEffect(terminal.logs.size) {
    if (terminal.logs.isNotEmpty()) {
      runCatching { listState.animateScrollToItem(terminal.logs.lastIndex) }
    }
  }

  Dialog(
    onDismissRequest = { if (terminal.isCompleted && !terminal.isRunning) onDismiss() },
    properties =
      DialogProperties(
        dismissOnBackPress = terminal.isCompleted && !terminal.isRunning,
        dismissOnClickOutside = false,
        usePlatformDefaultWidth = false,
      ),
  ) {
    BackHandler(enabled = terminal.isRunning) {}

    val progress =
      if (terminal.totalSteps > 0) {
        (terminal.currentStep.toFloat() / terminal.totalSteps.toFloat()).coerceIn(0f, 1f)
      } else {
        0f
      }
    val percent = (progress * 100).toInt()

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp)
          .clip(RoundedCornerShape(16.dp))
          .background(FangxDeepBlack)
          .border(1.5.dp, FangxCyan, RoundedCornerShape(16.dp))
          .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = if (terminal.isCompleted) Icons.Filled.CheckCircle else Icons.Filled.Terminal,
            contentDescription = "Console Terminal",
            tint = if (terminal.isCompleted) FangxNeonGreen else FangxCyan,
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text =
              if (terminal.mode == TerminalMode.RESTORE) "RESTAURAÇÃO ANDROID"
              else "FANGX TERMINAL • 40MS",
            color = FangxCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
          )
        }
        Text(
          text = "$percent%",
          color = if (terminal.isCompleted) FangxNeonGreen else FangxCyan,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Black,
          fontSize = 15.sp,
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      LinearProgressIndicator(
        progress = { progress },
        modifier =
          Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
        color = if (terminal.isCompleted) FangxNeonGreen else FangxCyan,
        trackColor = FangxGraphiteElevated,
      )

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = terminal.currentCommand,
        color = FangxTextPrimary,
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.testTag("terminal_status_text"),
      )

      Spacer(modifier = Modifier.height(10.dp))

      LazyColumn(
        state = listState,
        modifier =
          Modifier
            .fillMaxWidth()
            .heightIn(min = 180.dp, max = 270.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(FangxGraphite)
            .border(1.dp, FangxBorderSubtle, RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        items(terminal.logs, key = { it.index }) { entry ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "[${entry.index}/${terminal.totalSteps}]",
              color = FangxCyan,
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = entry.command,
              color = FangxTextSecondary,
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = entry.statusTag,
              color = if (entry.isError) FangxNeonRed else FangxNeonGreen,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (terminal.isCompleted) {
        if (terminal.copiedForBrevent) {
          Row(
            modifier =
              Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(FangxGraphiteElevated)
                .border(1.dp, FangxCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Filled.ContentCopy,
              contentDescription = null,
              tint = FangxCyan,
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Pacote com ${terminal.totalSteps} comandos copiado para o Clipboard (Brevent).",
              color = FangxTextPrimary,
              fontFamily = FontFamily.Default,
              fontSize = 12.sp,
            )
          }
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedButton(
              onClick = onOpenBrevent,
              modifier = Modifier.weight(1f).height(48.dp).testTag("open_brevent_button"),
              shape = RoundedCornerShape(10.dp),
            ) {
              Text(
                text = "ABRIR BREVENT",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = FangxCyan,
              )
            }
            Button(
              onClick = onOpenGame,
              modifier = Modifier.weight(1f).height(48.dp).testTag("open_game_after_brevent_button"),
              colors = ButtonDefaults.buttonColors(containerColor = FangxNeonRed),
              shape = RoundedCornerShape(10.dp),
            ) {
              Icon(Icons.Filled.PlayArrow, contentDescription = null)
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "ABRIR JOGO",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = FangxTextPrimary,
              )
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
        }

        Button(
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("close_terminal_button"),
          colors = ButtonDefaults.buttonColors(containerColor = FangxCyan, contentColor = FangxDeepBlack),
          shape = RoundedCornerShape(10.dp),
        ) {
          Icon(Icons.Filled.Close, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "CONCLUIR E FECHAR",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
          )
        }
      } else {
        Text(
          text = "Aguarde a conclusão de 100% da fila cadenciada...",
          color = FangxTextSecondary,
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
        )
      }
    }
  }
}
