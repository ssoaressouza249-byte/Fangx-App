package com.raylan.fangx

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.roundToInt

enum class DeviceBrand(val displayName: String) {
  SAMSUNG("Samsung"),
  XIAOMI("Xiaomi / POCO / Redmi"),
  MOTOROLA("Motorola"),
  REALME("Realme / OPPO"),
  ASUS("ASUS ROG"),
  OTHER("Genérico / AOSP"),
}

data class DeviceInfo(
  val manufacturer: String,
  val model: String,
  val androidRelease: String,
  val sdkInt: Int,
  val widthPx: Int,
  val heightPx: Int,
  val dpi: Int,
  val maxRefreshRateHz: Int,
  val supportedRefreshRates: List<Int>,
  val totalRamMb: Long,
  val totalRamGbFormatted: String,
  val brandCategory: DeviceBrand,
  val isFreeFireNormalInstalled: Boolean,
  val isFreeFireMaxInstalled: Boolean,
  val isShizukuInstalled: Boolean,
  val isBreventInstalled: Boolean,
) {
  val resolutionLabel: String
    get() = "${widthPx}x${heightPx}"

  val fullDeviceTitle: String
    get() = "$manufacturer $model".trim()
}

object DeviceTelemetryDetector {

  const val PKG_FREE_FIRE_NORMAL = "com.dts.freefireth"
  const val PKG_FREE_FIRE_MAX = "com.dts.freefiremax"
  const val PKG_SHIZUKU = "moe.shizuku.privileged.api"
  const val PKG_BREVENT = "me.piebridge.brevent"

  fun detect(context: Context): DeviceInfo {
    val manufacturer =
      runCatching { Build.MANUFACTURER.orEmpty().ifBlank { "Android" } }
        .getOrDefault("Android")
    val model =
      runCatching { Build.MODEL.orEmpty().ifBlank { "Device" } }
        .getOrDefault("Device")
    val androidRelease =
      runCatching { Build.VERSION.RELEASE.orEmpty().ifBlank { "Unknown" } }
        .getOrDefault("Unknown")
    val sdkInt = runCatching { Build.VERSION.SDK_INT }.getOrDefault(26)

    val displayMetrics = context.resources.displayMetrics
    var widthPx = displayMetrics.widthPixels
    var heightPx = displayMetrics.heightPixels
    val dpi = displayMetrics.densityDpi

    runCatching {
      val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
      if (wm != null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          val bounds = wm.maximumWindowMetrics.bounds
          if (bounds.width() > 0 && bounds.height() > 0) {
            widthPx = bounds.width()
            heightPx = bounds.height()
          }
        } else {
          val realMetrics = DisplayMetrics()
          @Suppress("DEPRECATION")
          wm.defaultDisplay?.getRealMetrics(realMetrics)
          if (realMetrics.widthPixels > 0 && realMetrics.heightPixels > 0) {
            widthPx = realMetrics.widthPixels
            heightPx = realMetrics.heightPixels
          }
        }
      }
    }

    val rates = mutableSetOf<Int>()
    var maxRefreshRate = 60
    runCatching {
      val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
      val display =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          runCatching { context.display }.getOrNull() ?: @Suppress("DEPRECATION") wm?.defaultDisplay
        } else {
          @Suppress("DEPRECATION") wm?.defaultDisplay
        }
      if (display != null) {
        val currentRate = display.refreshRate.roundToInt().coerceAtLeast(60)
        rates.add(currentRate)
        display.supportedModes?.forEach { mode ->
          val hz = mode.refreshRate.roundToInt()
          if (hz >= 30) rates.add(hz)
        }
        maxRefreshRate = (rates.maxOrNull() ?: currentRate).coerceAtLeast(60)
      }
    }
    if (rates.isEmpty()) rates.add(60)

    var totalRamMb = 4096L
    runCatching {
      val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      if (am != null) {
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        if (memInfo.totalMem > 0L) {
          totalRamMb = memInfo.totalMem / (1024L * 1024L)
        }
      }
    }
    val ramGb = totalRamMb / 1024.0
    val ramFormatted = String.format(java.util.Locale.US, "%.1f GB", ramGb)

    val brandLower = manufacturer.lowercase()
    val brandCategory =
      when {
        brandLower.contains("samsung") -> DeviceBrand.SAMSUNG
        brandLower.contains("xiaomi") ||
          brandLower.contains("redmi") ||
          brandLower.contains("poco") -> DeviceBrand.XIAOMI
        brandLower.contains("motorola") || brandLower.contains("moto") -> DeviceBrand.MOTOROLA
        brandLower.contains("realme") || brandLower.contains("oppo") -> DeviceBrand.REALME
        brandLower.contains("asus") -> DeviceBrand.ASUS
        else -> DeviceBrand.OTHER
      }

    return DeviceInfo(
      manufacturer = manufacturer.replaceFirstChar { it.uppercase() },
      model = model,
      androidRelease = androidRelease,
      sdkInt = sdkInt,
      widthPx = minOf(widthPx, heightPx),
      heightPx = maxOf(widthPx, heightPx),
      dpi = dpi,
      maxRefreshRateHz = maxRefreshRate,
      supportedRefreshRates = rates.sorted(),
      totalRamMb = totalRamMb,
      totalRamGbFormatted = ramFormatted,
      brandCategory = brandCategory,
      isFreeFireNormalInstalled = isPackageInstalled(context, PKG_FREE_FIRE_NORMAL),
      isFreeFireMaxInstalled = isPackageInstalled(context, PKG_FREE_FIRE_MAX),
      isShizukuInstalled = isPackageInstalled(context, PKG_SHIZUKU),
      isBreventInstalled = isPackageInstalled(context, PKG_BREVENT),
    )
  }

  fun isPackageInstalled(context: Context, packageName: String): Boolean =
    runCatching {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        context.packageManager.getPackageInfo(
          packageName,
          PackageManager.PackageInfoFlags.of(0L),
        )
      } else {
        @Suppress("DEPRECATION")
        context.packageManager.getPackageInfo(packageName, 0)
      }
      true
    }
      .getOrDefault(false)
}
