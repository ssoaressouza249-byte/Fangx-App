package com.raylan.fangx.overlay

import android.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class CrosshairStyle(val label: String) {
  CROSS("Mira Cruz"),
  LASER_DOT("Ponto Laser"),
  TACTICAL_RETICLE("Retículo Tático"),
  X_SNIPER("X-Sniper"),
  PRO_CIRCLE("Círculo Pro"),
}

enum class CrosshairColorOption(val label: String, val argb: Int) {
  CYAN("Ciano", Color.parseColor("#00F0FF")),
  NEON_RED("Vermelho", Color.parseColor("#FF1E42")),
  NEON_GREEN("Verde", Color.parseColor("#00FF88")),
  AMBER("Amarelo", Color.parseColor("#FFD600")),
  WHITE("Branco", Color.parseColor("#FFFFFF")),
}

data class CrosshairConfig(
  val isOverlayActive: Boolean = false,
  val showCrosshair: Boolean = true,
  val style: CrosshairStyle = CrosshairStyle.TACTICAL_RETICLE,
  val colorOption: CrosshairColorOption = CrosshairColorOption.CYAN,
  val sizeDp: Float = 24f,
  val strokeWidthDp: Float = 2.2f,
)

object OverlayStateStore {
  private val _config = MutableStateFlow(CrosshairConfig())
  val config: StateFlow<CrosshairConfig> = _config.asStateFlow()

  fun update(transform: (CrosshairConfig) -> CrosshairConfig) {
    _config.update(transform)
  }

  fun cycleStyle() {
    val entries = CrosshairStyle.entries
    _config.update { current ->
      val nextIdx = (entries.indexOf(current.style) + 1) % entries.size
      current.copy(style = entries[nextIdx])
    }
  }

  fun cycleColor() {
    val entries = CrosshairColorOption.entries
    _config.update { current ->
      val nextIdx = (entries.indexOf(current.colorOption) + 1) % entries.size
      current.copy(colorOption = entries[nextIdx])
    }
  }
}
