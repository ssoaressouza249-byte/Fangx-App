package com.raylan.fangx

import kotlin.random.Random

data class SensitivityProfile(
  val geral: Int,
  val pontoVermelho: Int,
  val mira2x: Int,
  val mira4x: Int,
  val awm: Int,
  val olhadinha: Int,
  val recommendedDpi: Int,
  val recommendedResolutionLabel: String,
  val recommendedFireButtonPercent: Int,
  val dragTips: List<String>,
  val generatedForModel: String,
) {
  fun toClipboardText(): String {
    return buildString {
      appendLine("══ FANGX • SENSI CALIBRADA ($generatedForModel) ══")
      appendLine("• Geral: $geral")
      appendLine("• Ponto Vermelho: $pontoVermelho")
      appendLine("• Mira 2x: $mira2x")
      appendLine("• Mira 4x: $mira4x")
      appendLine("• Mira AWM: $awm")
      appendLine("• Olhadinha: $olhadinha")
      appendLine()
      appendLine("▶ DPI & Resolução Recomendados:")
      appendLine("• DPI: $recommendedDpi | Tela: $recommendedResolutionLabel")
      appendLine("• Botão de Atirar: $recommendedFireButtonPercent%")
      appendLine()
      appendLine("▶ Dicas de Puxada Calibradas:")
      dragTips.forEachIndexed { idx, tip -> appendLine("${idx + 1}. $tip") }
      appendLine()
      append("Fangx • Criado por Raylan • Versão VIP Oficial")
    }
  }
}

object SensitivityGenerator {

  fun generate(deviceInfo: DeviceInfo): SensitivityProfile {
    val dpiBoostBase =
      when {
        deviceInfo.dpi >= 500 -> 148
        deviceInfo.dpi >= 420 -> 162
        else -> 174
      }
    val hzFactor = if (deviceInfo.maxRefreshRateHz >= 120) 10 else 0

    fun clamped(base: Int, spread: Int): Int {
      val value = base + hzFactor + Random.nextInt(-spread, spread + 1)
      return value.coerceIn(100, 200)
    }

    val geral = clamped(dpiBoostBase + 16, 14)
    val pontoVermelho = clamped(dpiBoostBase + 12, 16)
    val mira2x = clamped(dpiBoostBase + 8, 18)
    val mira4x = clamped(dpiBoostBase + 4, 20)
    val awm = clamped(124 + (if (deviceInfo.dpi < 400) 18 else 6), 24)
    val olhadinha = clamped(158, 28)

    val recommendedDpi =
      when {
        deviceInfo.widthPx >= 1200 -> 720
        deviceInfo.dpi >= 460 -> 640
        deviceInfo.dpi >= 380 -> 596
        else -> 540
      }

    val fireButtonPercent =
      when {
        deviceInfo.heightPx >= 2400 -> 44
        deviceInfo.heightPx >= 2160 -> 48
        else -> 52
      }

    val dragStyle =
      if (deviceInfo.maxRefreshRateHz >= 120) {
        "Puxada curta em 'J' com taxa de ${deviceInfo.maxRefreshRateHz}Hz: suba rápido nos primeiros 30% do movimento."
      } else {
        "Puxada retilínea contínua para ${deviceInfo.maxRefreshRateHz}Hz: evite soltar o dedo antes do primeiro headshot."
      }

    val tips =
      listOf(
        dragStyle,
        "Botão de atirar em $fireButtonPercent% posicionado levemente abaixo da linha média para telas ${deviceInfo.resolutionLabel}.",
        "Use DPI em $recommendedDpi (ou próximo) com Mira Geral $geral para compensar a densidade nativa de ${deviceInfo.dpi} dpi do ${deviceInfo.model}.",
        "Em curta distância (SMG/12), puxe do centro para cima em movimento seco; em média distância (AR com 2x em $mira2x), dê rajadas de 3 a 4 tiros.",
      )

    return SensitivityProfile(
      geral = geral,
      pontoVermelho = pontoVermelho,
      mira2x = mira2x,
      mira4x = mira4x,
      awm = awm,
      olhadinha = olhadinha,
      recommendedDpi = recommendedDpi,
      recommendedResolutionLabel = "${deviceInfo.resolutionLabel} (${deviceInfo.maxRefreshRateHz}Hz)",
      recommendedFireButtonPercent = fireButtonPercent,
      dragTips = tips,
      generatedForModel = deviceInfo.fullDeviceTitle,
    )
  }
}
