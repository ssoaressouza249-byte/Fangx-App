package com.raylan.fangx.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.FangxBorderSubtle
import com.example.ui.theme.FangxCyan
import com.example.ui.theme.FangxDeepBlack
import com.example.ui.theme.FangxGraphite
import com.example.ui.theme.FangxGraphiteElevated
import com.example.ui.theme.FangxNeonGreen
import com.example.ui.theme.FangxNeonRed
import com.example.ui.theme.FangxNeonRedDark
import com.example.ui.theme.FangxTextPrimary
import com.example.ui.theme.FangxTextSecondary
import com.raylan.fangx.CommandBank
import com.raylan.fangx.EngineModule
import com.raylan.fangx.FangxUiState
import com.raylan.fangx.FangxViewModel
import com.raylan.fangx.GameTarget

private enum class FangxTab(val label: String, val icon: ImageVector) {
  ENGINE("ENGINE", Icons.Filled.Bolt),
  SENSI("SENSI", Icons.Filled.Tune),
  OVERLAY("MIRA HUD", Icons.Filled.CenterFocusStrong),
}

@Composable
fun FangxRootScreen(viewModel: FangxViewModel) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val crosshairConfig by viewModel.crosshairConfig.collectAsStateWithLifecycle()

  if (!state.securityStatus.isIntact) {
    TamperLockScreen(violationReason = state.securityStatus.violationReason)
    return
  }

  val context = LocalContext.current
  val snackbarHostState = remember { SnackbarHostState() }
  var selectedTabIdx by rememberSaveable { mutableIntStateOf(0) }

  val overlayPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
      viewModel.refreshSystemStatuses()
    }

  LaunchedEffect(state.snackbarMessage) {
    val msg = state.snackbarMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearSnackbar()
    }
  }

  TerminalInjectionDialog(
    terminal = state.terminal,
    onOpenBrevent = { viewModel.openBrevent() },
    onOpenGame = { viewModel.openSelectedFreeFire() },
    onDismiss = { viewModel.closeTerminalIfFinished() },
  )

  BoxWithConstraints(modifier = Modifier.fillMaxSize().background(FangxDeepBlack)) {
    val isExpanded = maxWidth >= 840.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (isExpanded) {
        NavigationRail(
          containerColor = FangxGraphite,
          contentColor = FangxCyan,
          modifier = Modifier.fillMaxHeight(),
        ) {
          Spacer(modifier = Modifier.height(16.dp))
          FangxTab.entries.forEachIndexed { idx, tab ->
            NavigationRailItem(
              selected = selectedTabIdx == idx,
              onClick = { selectedTabIdx = idx },
              icon = { Icon(tab.icon, contentDescription = tab.label) },
              label = {
                Text(
                  text = tab.label,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp,
                )
              },
              colors =
                NavigationRailItemDefaults.colors(
                  selectedIconColor = FangxDeepBlack,
                  selectedTextColor = FangxCyan,
                  indicatorColor = FangxCyan,
                  unselectedIconColor = FangxTextSecondary,
                  unselectedTextColor = FangxTextSecondary,
                ),
            )
          }
        }
      }

      Scaffold(
        modifier = Modifier.weight(1f).fillMaxHeight(),
        containerColor = FangxDeepBlack,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = {
          SnackbarHost(snackbarHostState) { data ->
            Snackbar(
              snackbarData = data,
              containerColor = FangxGraphiteElevated,
              contentColor = FangxCyan,
            )
          }
        },
        bottomBar = {
          if (!isExpanded) {
            NavigationBar(
              containerColor = FangxGraphite,
              modifier =
                Modifier
                  .border(1.dp, FangxBorderSubtle)
                  .navigationBarsPadding(),
            ) {
              FangxTab.entries.forEachIndexed { idx, tab ->
                NavigationBarItem(
                  selected = selectedTabIdx == idx,
                  onClick = { selectedTabIdx = idx },
                  icon = { Icon(tab.icon, contentDescription = tab.label) },
                  label = {
                    Text(
                      text = tab.label,
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold,
                      fontSize = 11.sp,
                    )
                  },
                  modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                  colors =
                    NavigationBarItemDefaults.colors(
                      selectedIconColor = FangxDeepBlack,
                      selectedTextColor = FangxCyan,
                      indicatorColor = FangxCyan,
                      unselectedIconColor = FangxTextSecondary,
                      unselectedTextColor = FangxTextSecondary,
                    ),
                )
              }
            }
          }
        },
      ) { innerPadding ->
        Box(
          modifier = Modifier.fillMaxSize().padding(innerPadding),
          contentAlignment = Alignment.TopCenter,
        ) {
          LazyColumn(
            modifier = Modifier.fillMaxSize().widthIn(max = 920.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            item {
              FangxHeroHeader(
                shizukuState = state.shizukuState,
                onRefreshTelemetry = { viewModel.refreshSystemStatuses() },
              )
            }

            item {
              DeviceTelemetryCard(
                deviceInfo = state.deviceInfo,
                shizukuState = state.shizukuState,
                onRequestShizuku = { viewModel.requestShizukuPermission() },
              )
            }

            when (FangxTab.entries[selectedTabIdx]) {
              FangxTab.ENGINE -> {
                item {
                  TargetGameSelectorCard(
                    state = state,
                    onSelectGame = { viewModel.selectGame(it) },
                  )
                }

                item {
                  SectionCounterHeader(
                    icon = Icons.Filled.GpsFixed,
                    title = "MÓDULOS DE MIRA & MOVIMENTO",
                    counterText = "Banco de Mira: ${state.compatibleAimCount}/100 comandos compatíveis",
                    accentColor = FangxCyan,
                  )
                }

                val aimModules = EngineModule.entries.filter { it.bank == CommandBank.AIM }
                items(aimModules.size, key = { aimModules[it].name }) { i ->
                  val mod = aimModules[i]
                  val compat = state.moduleCompatibilityMap[mod]
                  if (compat != null) {
                    EngineModuleSwitchCard(
                      compatibility = compat,
                      checked = mod in state.enabledModules,
                      deviceModel = state.deviceInfo.model,
                      onToggle = { viewModel.toggleModule(mod) },
                    )
                  }
                }

                item {
                  SectionCounterHeader(
                    icon = Icons.Filled.Speed,
                    title = "DESEMPENHO, CPU/GPU, HZ & FPS",
                    counterText =
                      "Banco de Desempenho: ${state.compatiblePerformanceCount}/100 comandos compatíveis",
                    accentColor = FangxNeonRed,
                  )
                }

                item {
                  RefreshRateSelectorCard(
                    selectedHz = state.selectedRefreshRateHz,
                    maxSupportedHz = state.deviceInfo.maxRefreshRateHz,
                    onSelectHz = { viewModel.selectRefreshRate(it) },
                  )
                }

                val perfModules = EngineModule.entries.filter { it.bank == CommandBank.PERFORMANCE }
                items(perfModules.size, key = { perfModules[it].name }) { i ->
                  val mod = perfModules[i]
                  val compat = state.moduleCompatibilityMap[mod]
                  if (compat != null) {
                    EngineModuleSwitchCard(
                      compatibility = compat,
                      checked = mod in state.enabledModules,
                      deviceModel = state.deviceInfo.model,
                      onToggle = { viewModel.toggleModule(mod) },
                    )
                  }
                }

                item {
                  InjectAndRestoreActions(
                    onInjectAndLaunch = { viewModel.startCadencedInjection() },
                    onRestoreFactory = { viewModel.startRestoreFactoryDefaults() },
                  )
                }
              }

              FangxTab.SENSI -> {
                item {
                  SensitivityGeneratorTab(
                    profile = state.sensitivityProfile,
                    deviceInfo = state.deviceInfo,
                    onGenerateNew = { viewModel.generateNewSensitivity() },
                    onCopyAll = { viewModel.copySensitivityAndTips() },
                  )
                }
              }

              FangxTab.OVERLAY -> {
                item {
                  FloatingCrosshairTab(
                    config = crosshairConfig,
                    hasOverlayPermission = state.hasOverlayPermission,
                    onToggleOverlayService = {
                      viewModel.toggleFloatingOverlay {
                        runCatching {
                          val intent =
                            Intent(
                              Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                              Uri.parse("package:${context.packageName}"),
                            )
                          overlayPermissionLauncher.launch(intent)
                        }
                      }
                    },
                    onToggleCrosshairVisibility = { viewModel.toggleCrosshairVisibility() },
                    onSelectStyle = { viewModel.updateCrosshairStyle(it) },
                    onSelectColor = { viewModel.updateCrosshairColor(it) },
                    onSizeChange = { viewModel.updateCrosshairSize(it) },
                  )
                }
              }
            }

            item { OfficialCreditsFooter() }
          }
        }
      }
    }
  }
}

@Composable
private fun SectionCounterHeader(
  icon: ImageVector,
  title: String,
  counterText: String,
  accentColor: androidx.compose.ui.graphics.Color,
) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .padding(top = 6.dp)
        .clip(RoundedCornerShape(10.dp))
        .background(FangxGraphite)
        .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
        .padding(horizontal = 14.dp, vertical = 10.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = title,
        color = FangxTextPrimary,
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 14.sp,
      )
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = counterText,
      color = accentColor,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 12.sp,
      modifier = Modifier.testTag("section_counter_${title.take(12)}"),
    )
  }
}

@Composable
private fun RefreshRateSelectorCard(
  selectedHz: Int,
  maxSupportedHz: Int,
  onSelectHz: (Int) -> Unit,
) {
  val options = listOf(90, 120, 144)
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(FangxGraphite)
        .border(1.dp, FangxBorderSubtle, RoundedCornerShape(12.dp))
        .padding(14.dp)
  ) {
    Text(
      text = "SELETOR DE TAXA DE ATUALIZAÇÃO (DISPLAY: ${maxSupportedHz}Hz)",
      color = FangxTextSecondary,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp,
    )
    Spacer(modifier = Modifier.height(10.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      options.forEach { hz ->
        val compatible = maxSupportedHz >= hz
        val selected = compatible && selectedHz == hz
        Box(
          modifier =
            Modifier
              .weight(1f)
              .height(48.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(
                when {
                  !compatible -> FangxNeonRedDark.copy(alpha = 0.5f)
                  selected -> FangxCyan.copy(alpha = 0.2f)
                  else -> FangxGraphiteElevated
                }
              )
              .border(
                width = if (selected) 1.5.dp else 1.dp,
                color =
                  when {
                    !compatible -> FangxNeonRed.copy(alpha = 0.6f)
                    selected -> FangxCyan
                    else -> FangxBorderSubtle
                  },
                shape = RoundedCornerShape(10.dp),
              )
              .clickable(enabled = compatible) { onSelectHz(hz) }
              .testTag("hz_selector_$hz"),
          contentAlignment = Alignment.Center,
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "${hz}Hz",
              color =
                when {
                  !compatible -> FangxNeonRed
                  selected -> FangxCyan
                  else -> FangxTextPrimary
                },
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Black,
              fontSize = 13.sp,
            )
            if (!compatible) {
              Text(
                text = "BLOQUEADO",
                color = FangxNeonRed,
                fontFamily = FontFamily.Monospace,
                fontSize = 8.sp,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun TargetGameSelectorCard(
  state: FangxUiState,
  onSelectGame: (GameTarget) -> Unit,
) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(FangxGraphite)
        .border(1.dp, FangxBorderSubtle, RoundedCornerShape(12.dp))
        .padding(14.dp)
  ) {
    Text(
      text = "ALVO DE INJEÇÃO AUTOMÁTICA",
      color = FangxCyan,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp,
    )
    Spacer(modifier = Modifier.height(10.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      GameTarget.entries.forEach { target ->
        val selected = state.selectedGame == target
        val installed =
          if (target == GameTarget.FREE_FIRE_NORMAL) state.deviceInfo.isFreeFireNormalInstalled
          else state.deviceInfo.isFreeFireMaxInstalled

        Column(
          modifier =
            Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (selected) FangxCyan.copy(alpha = 0.14f) else FangxGraphiteElevated)
              .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) FangxCyan else FangxBorderSubtle,
                shape = RoundedCornerShape(10.dp),
              )
              .clickable { onSelectGame(target) }
              .padding(12.dp)
              .testTag("game_target_${target.name.lowercase()}"),
        ) {
          Text(
            text = target.label,
            color = if (selected) FangxCyan else FangxTextPrimary,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.sp,
          )
          Spacer(modifier = Modifier.height(3.dp))
          Text(
            text = if (installed) "● INSTALADO" else "○ NÃO DETECTADO",
            color = if (installed) FangxNeonGreen else FangxTextSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
          )
        }
      }
    }
  }
}

@Composable
private fun InjectAndRestoreActions(
  onInjectAndLaunch: () -> Unit,
  onRestoreFactory: () -> Unit,
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Button(
      onClick = onInjectAndLaunch,
      colors = ButtonDefaults.buttonColors(containerColor = FangxNeonRed, contentColor = FangxTextPrimary),
      shape = RoundedCornerShape(14.dp),
      modifier =
        Modifier
          .fillMaxWidth()
          .height(62.dp)
          .border(1.5.dp, FangxCyan, RoundedCornerShape(14.dp))
          .testTag("inject_and_launch_button"),
    ) {
      Icon(Icons.Filled.RocketLaunch, contentDescription = null, modifier = Modifier.size(24.dp))
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = "INJETAR & ABRIR JOGO",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Black,
        fontSize = 16.sp,
        letterSpacing = 1.sp,
      )
    }

    OutlinedButton(
      onClick = onRestoreFactory,
      border = BorderStroke(1.dp, FangxBorderSubtle),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth().height(50.dp).testTag("restore_factory_button"),
    ) {
      Icon(Icons.Filled.Restore, contentDescription = null, tint = FangxTextSecondary)
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "RESTAURAR PADRÃO ORIGINAL DO ANDROID",
        color = FangxTextSecondary,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
      )
    }
  }
}
