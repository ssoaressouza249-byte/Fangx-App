package com.raylan.fangx.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.FangxAmber
import com.example.ui.theme.FangxBorderSubtle
import com.example.ui.theme.FangxCyan
import com.example.ui.theme.FangxDeepBlack
import com.example.ui.theme.FangxGraphite
import com.example.ui.theme.FangxGraphiteElevated
import com.example.ui.theme.FangxNeonGreen
import com.example.ui.theme.FangxNeonRed
import com.example.ui.theme.FangxNeonRedDark
import com.example.ui.theme.FangxTextPrimary
import com.example.ui.theme.FangxTextSecondary
import com.raylan.fangx.DeviceInfo
import com.raylan.fangx.ModuleCompatibility
import com.raylan.fangx.ShizukuConnectionState

@Composable
fun FangxHeroHeader(
  shizukuState: ShizukuConnectionState,
  onRefreshTelemetry: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .border(1.5.dp, FangxCyan.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
  ) {
    Image(
      painter = painterResource(id = R.drawable.img_fangx_hero),
      contentDescription = "FANGX Pro Engine Banner",
      contentScale = ContentScale.Crop,
      modifier = Modifier.matchParentSize(),
    )
    Box(
      modifier =
        Modifier
          .matchParentSize()
          .background(
            Brush.horizontalGradient(
              colors =
                listOf(
                  FangxDeepBlack.copy(alpha = 0.94f),
                  FangxDeepBlack.copy(alpha = 0.78f),
                  FangxDeepBlack.copy(alpha = 0.58f),
                )
            )
          )
    )
    Column(modifier = Modifier.fillMaxWidth().padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "FANGX",
            style = MaterialTheme.typography.displaySmall,
            color = FangxCyan,
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Black,
            letterSpacing = 3.sp,
            modifier = Modifier.testTag("hero_title"),
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = stringResource(R.string.engine_subtitle),
            color = FangxTextPrimary,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            letterSpacing = 0.8.sp,
            modifier = Modifier.testTag("hero_subtitle"),
          )
        }
        IconButton(
          onClick = onRefreshTelemetry,
          modifier =
            Modifier
              .size(48.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(FangxGraphite.copy(alpha = 0.85f))
              .border(1.dp, FangxCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
              .testTag("refresh_telemetry_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Refresh,
            contentDescription = "Atualizar hardware e serviços",
            tint = FangxCyan,
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Box(
          modifier =
            Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(FangxNeonRedDark)
              .border(1.dp, FangxNeonRed, RoundedCornerShape(6.dp))
              .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = stringResource(R.string.author_badge),
            color = FangxTextPrimary,
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.testTag("author_badge"),
          )
        }
        val statusColor =
          when (shizukuState) {
            ShizukuConnectionState.CONNECTED -> FangxNeonGreen
            ShizukuConnectionState.NEEDS_PERMISSION -> FangxAmber
            else -> FangxCyan
          }
        Box(
          modifier =
            Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(FangxGraphite.copy(alpha = 0.9f))
              .border(1.dp, statusColor.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
              .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text =
              if (shizukuState == ShizukuConnectionState.CONNECTED) "SHIZUKU ON"
              else "MODO BREVENT / ADB",
            color = statusColor,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeviceTelemetryCard(
  deviceInfo: DeviceInfo,
  shizukuState: ShizukuConnectionState,
  onRequestShizuku: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = FangxGraphite),
    border = BorderStroke(1.dp, FangxCyan.copy(alpha = 0.45f)),
    shape = RoundedCornerShape(14.dp),
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.DeveloperBoard,
            contentDescription = null,
            tint = FangxCyan,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "TELEMETRIA DE HARDWARE",
            color = FangxCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
          )
        }
        Text(
          text = deviceInfo.brandCategory.displayName,
          color = FangxTextSecondary,
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        TelemetryChip(Icons.Filled.PhoneAndroid, "Aparelho", "${deviceInfo.manufacturer} ${deviceInfo.model}")
        TelemetryChip(Icons.Filled.Security, "Android", "v${deviceInfo.androidRelease} (SDK ${deviceInfo.sdkInt})")
        TelemetryChip(Icons.Filled.Speed, "Display", "${deviceInfo.resolutionLabel} • ${deviceInfo.dpi} DPI")
        TelemetryChip(Icons.Filled.Bolt, "Max Hz", "${deviceInfo.maxRefreshRateHz} Hz")
        TelemetryChip(Icons.Filled.Memory, "RAM", deviceInfo.totalRamGbFormatted)
      }

      if (shizukuState != ShizukuConnectionState.CONNECTED) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier =
            Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(FangxGraphiteElevated)
              .border(1.dp, FangxBorderSubtle, RoundedCornerShape(8.dp))
              .clickable { onRequestShizuku() }
              .padding(horizontal = 12.dp, vertical = 10.dp)
              .testTag("shizuku_status_banner"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = shizukuState.label,
              color = FangxAmber,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
            )
            Text(
              text =
                if (deviceInfo.isBreventInstalled) "Brevent detectado • Toque p/ autorizar Shizuku ou injete via Brevent"
                else "Toque p/ conectar Shizuku ou copie para Brevent ao injetar",
              color = FangxTextSecondary,
              fontSize = 11.sp,
            )
          }
          Text(
            text = "CONECTAR",
            color = FangxCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp,
          )
        }
      }
    }
  }
}

@Composable
private fun TelemetryChip(icon: ImageVector, label: String, value: String) {
  Row(
    modifier =
      Modifier
        .clip(RoundedCornerShape(8.dp))
        .background(FangxGraphiteElevated)
        .border(1.dp, FangxBorderSubtle, RoundedCornerShape(8.dp))
        .padding(horizontal = 10.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = FangxCyan,
      modifier = Modifier.size(14.dp),
    )
    Spacer(modifier = Modifier.width(6.dp))
    Column {
      Text(
        text = label,
        color = FangxTextSecondary,
        fontFamily = FontFamily.Monospace,
        fontSize = 9.sp,
      )
      Text(
        text = value,
        color = FangxTextPrimary,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
      )
    }
  }
}

@Composable
fun EngineModuleSwitchCard(
  compatibility: ModuleCompatibility,
  checked: Boolean,
  deviceModel: String,
  onToggle: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val isCompatible = compatibility.isCompatible
  val borderColor =
    when {
      !isCompatible -> FangxNeonRed.copy(alpha = 0.65f)
      checked -> FangxCyan
      else -> FangxBorderSubtle
    }

  Card(
    modifier =
      modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .clickable(enabled = isCompatible) { onToggle() }
        .testTag("module_card_${compatibility.module.name.lowercase()}"),
    colors =
      CardDefaults.cardColors(
        containerColor = if (checked && isCompatible) FangxGraphiteElevated else FangxGraphite
      ),
    border = BorderStroke(if (checked && isCompatible) 1.5.dp else 1.dp, borderColor),
    shape = RoundedCornerShape(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
        Text(
          text = compatibility.module.title,
          color = if (isCompatible) FangxTextPrimary else FangxTextSecondary,
          fontFamily = FontFamily.Default,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = compatibility.module.description,
          color = FangxTextSecondary,
          fontSize = 12.sp,
          lineHeight = 16.sp,
        )
        Spacer(modifier = Modifier.height(6.dp))
        if (!isCompatible) {
          Box(
            modifier =
              Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(FangxNeonRedDark)
                .border(1.dp, FangxNeonRed, RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "INCOMPATÍVEL COM ESTE APARELHO",
              color = FangxNeonRed,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Black,
              fontSize = 10.sp,
              modifier = Modifier.testTag("incompatible_badge_${compatibility.module.name.lowercase()}"),
            )
          }
          if (!compatibility.incompatibleReason.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = compatibility.incompatibleReason,
              color = FangxNeonRed.copy(alpha = 0.9f),
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp,
            )
          }
        } else {
          Text(
            text =
              "${compatibility.compatibleCommands.size}/${compatibility.totalCommands} comandos reais calibrados p/ $deviceModel",
            color = if (checked) FangxCyan else FangxTextSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }

      Switch(
        checked = checked && isCompatible,
        onCheckedChange = { if (isCompatible) onToggle() },
        enabled = isCompatible,
        modifier = Modifier.testTag("switch_${compatibility.module.name.lowercase()}"),
        colors =
          SwitchDefaults.colors(
            checkedThumbColor = FangxDeepBlack,
            checkedTrackColor = FangxCyan,
            uncheckedThumbColor = FangxTextSecondary,
            uncheckedTrackColor = FangxDeepBlack,
            uncheckedBorderColor = FangxBorderSubtle,
            disabledCheckedTrackColor = FangxNeonRedDark,
            disabledUncheckedTrackColor = FangxNeonRedDark.copy(alpha = 0.45f),
            disabledUncheckedThumbColor = FangxNeonRed.copy(alpha = 0.6f),
            disabledUncheckedBorderColor = FangxNeonRed.copy(alpha = 0.5f),
          ),
      )
    }
  }
}

@Composable
fun OfficialCreditsFooter(modifier: Modifier = Modifier) {
  Column(
    modifier = modifier.fillMaxWidth().padding(vertical = 12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(1.dp)
          .background(
            Brush.horizontalGradient(
              listOf(Color.Transparent, FangxCyan.copy(alpha = 0.4f), Color.Transparent)
            )
          )
    )
    Spacer(modifier = Modifier.height(10.dp))
    Text(
      text = stringResource(R.string.official_credits),
      color = FangxTextSecondary,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp,
      modifier = Modifier.testTag("official_credits_footer"),
    )
  }
}
