package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.raylan.fangx.SecurityGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name and security guard integrity pass for official Fangx build`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Fangx", appName)
    assertEquals("com.raylan.fangx", context.packageName)

    val status = SecurityGuard.verifyIntegrity(context)
    assertTrue("Expected SecurityGuard intact, got: ${status.violationReason}", status.isIntact)
  }
}
