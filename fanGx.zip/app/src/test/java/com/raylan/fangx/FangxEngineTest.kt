package com.raylan.fangx

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FangxEngineTest {

  private fun sampleDevice(sdkInt: Int, maxHz: Int, brand: DeviceBrand = DeviceBrand.SAMSUNG) =
    DeviceInfo(
      manufacturer = "Samsung",
      model = "SM-S928B",
      androidRelease = "14",
      sdkInt = sdkInt,
      widthPx = 1080,
      heightPx = 2400,
      dpi = 450,
      maxRefreshRateHz = maxHz,
      supportedRefreshRates = listOf(60, maxHz).distinct(),
      totalRamMb = 12288,
      totalRamGbFormatted = "12.0 GB",
      brandCategory = brand,
      isFreeFireNormalInstalled = true,
      isFreeFireMaxInstalled = true,
      isShizukuInstalled = false,
      isBreventInstalled = true,
    )

  @Test
  fun `command engine contains exactly 200 commands split 100 aim and 100 performance`() {
    assertEquals(200, MassiveCommandEngine.allCommands.size)
    assertEquals(100, MassiveCommandEngine.aimCommands.size)
    assertEquals(100, MassiveCommandEngine.performanceCommands.size)
    assertTrue(MassiveCommandEngine.verifyInternalModuleIntegrity())
  }

  @Test
  fun `compatibility filter blocks boost module on 60hz or android below 12`() {
    val dev60Hz = sampleDevice(sdkInt = 34, maxHz = 60)
    val compat60 =
      MassiveCommandEngine.evaluateModuleCompatibility(EngineModule.BOOST_CPU_GPU, dev60Hz, 90)
    assertFalse(compat60.isCompatible)

    val devAndroid11 = sampleDevice(sdkInt = 30, maxHz = 120)
    val compat11 =
      MassiveCommandEngine.evaluateModuleCompatibility(EngineModule.BOOST_CPU_GPU, devAndroid11, 120)
    assertFalse(compat11.isCompatible)

    val dev120HzA14 = sampleDevice(sdkInt = 34, maxHz = 120)
    val compatOk =
      MassiveCommandEngine.evaluateModuleCompatibility(EngineModule.BOOST_CPU_GPU, dev120HzA14, 120)
    assertTrue(compatOk.isCompatible)
    assertEquals(25, compatOk.compatibleCommands.size)
  }

  @Test
  fun `sensitivity generator always produces values in 100 to 200 range`() {
    val device = sampleDevice(sdkInt = 34, maxHz = 120)
    repeat(30) {
      val profile = SensitivityGenerator.generate(device)
      assertTrue(profile.geral in 100..200)
      assertTrue(profile.pontoVermelho in 100..200)
      assertTrue(profile.mira2x in 100..200)
      assertTrue(profile.mira4x in 100..200)
      assertTrue(profile.awm in 100..200)
      assertTrue(profile.olhadinha in 100..200)
    }
  }
}
